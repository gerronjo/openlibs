
// tiancityLoginDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "tiancityLogin.h"
#include "tiancityLoginDlg.h"
#include "afxdialogex.h"
#include <comutil.h>

#pragma   comment(lib, "comsupp.lib ") 

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CtiancityLoginDlg �Ի���

BEGIN_DHTML_EVENT_MAP(CtiancityLoginDlg)
	DHTML_EVENT_ONCLICK(_T("ButtonOK"), OnButtonOK)
END_DHTML_EVENT_MAP()





BEGIN_DISPATCH_MAP(CtiancityLoginDlg, CDHtmlDialog)
	DISP_FUNCTION(CtiancityLoginDlg,"Test",OnTest,VT_EMPTY,VTS_VARIANT VTS_VARIANT)
END_DISPATCH_MAP()
CtiancityLoginDlg::CtiancityLoginDlg(CWnd* pParent /*=NULL*/)
	: CDHtmlDialog(CtiancityLoginDlg::IDD, CtiancityLoginDlg::IDH, pParent)
	, m_msg1(_T(""))
	, m_msg2(_T(""))
	, m_msg3(_T(""))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CtiancityLoginDlg::DoDataExchange(CDataExchange* pDX)
{
	CDHtmlDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_LIST, m_list);
	DDX_Text(pDX, IDC_EDIT1, m_msg1);
	DDX_Text(pDX, IDC_EDIT2, m_msg2);
	DDX_Text(pDX, IDC_EDIT3, m_msg3);
}

BEGIN_MESSAGE_MAP(CtiancityLoginDlg, CDHtmlDialog)
END_MESSAGE_MAP()


// CtiancityLoginDlg ��Ϣ��������


BOOL CtiancityLoginDlg::OnInitDialog()
{
	CDHtmlDialog::OnInitDialog();

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������
	//src="res:/#144"
	EnableAutomation();
	SetExternalDispatch(GetIDispatch(TRUE));


	m_aLogin[0].m_pList=&m_list;
	m_aLogin[0].m_pMsg=&m_msg1;
	m_aLogin[0].m_hWnd=GetDlgItem(IDC_EDIT1)->m_hWnd;
	m_aLogin[0].Start();

	m_aLogin[1].m_pList=&m_list;
	m_aLogin[1].m_pMsg=&m_msg2;
	m_aLogin[1].m_hWnd=GetDlgItem(IDC_EDIT2)->m_hWnd;
	m_aLogin[1].Start();
	
	m_aLogin[2].m_pList=&m_list;
	m_aLogin[2].m_pMsg=&m_msg3;
	m_aLogin[2].m_hWnd=GetDlgItem(IDC_EDIT3)->m_hWnd;
	m_aLogin[2].Start();

	LONG lStyle;
	lStyle=GetWindowLong(m_list.m_hWnd, GWL_STYLE); //��ȡ��ǰ����style
	lStyle &= ~LVS_TYPEMASK; //�����ʾ��ʽλ
	lStyle |= LVS_REPORT; //����style
	SetWindowLong(m_list.m_hWnd, GWL_STYLE, lStyle); //����style
	m_list.InsertColumn(0,"���ƺ�����",LVCFMT_LEFT,260); //������
	m_list.InsertColumn(1,"�ʺ����",LVCFMT_LEFT,580/3);
	m_list.InsertColumn(2,"�ʺŻ���",LVCFMT_LEFT,580/3);
	m_list.InsertColumn(3,"������",LVCFMT_LEFT,580/3);

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CtiancityLoginDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ����������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDHtmlDialog::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù��
//��ʾ��
HCURSOR CtiancityLoginDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


HRESULT CallJSFunction(IHTMLDocument2* pDoc2,
	CString strFunctionName,
	DISPPARAMS dispParams,
	VARIANT* varResult,
	EXCEPINFO* exceptInfo,
	UINT* nArgErr )
{
	IDispatch *pDispScript = NULL;   
	HRESULT hResult;
	hResult = pDoc2->get_Script(&pDispScript);
	if(FAILED(hResult))
	{
		return S_FALSE;
	}
	DISPID   dispid;   
	CComBSTR objbstrValue = strFunctionName;
	BSTR bstrValue =  objbstrValue.Copy();
	OLECHAR   *pszFunct   =  bstrValue ; 
	hResult   =   pDispScript->GetIDsOfNames(IID_NULL, 
		&pszFunct, 
		1,
		LOCALE_SYSTEM_DEFAULT, 
		&dispid);   
	if   (S_OK   !=   hResult)   
	{ 
		pDispScript->Release();   
		return   hResult;   
	}  

	varResult->vt = VT_VARIANT;
	hResult   =   pDispScript->Invoke(dispid,
		IID_NULL, LOCALE_USER_DEFAULT,
		DISPATCH_METHOD,
		&dispParams,
		varResult,
		exceptInfo,
		nArgErr);  
	pDispScript->Release();
	return hResult;
}
//res:/#129
HRESULT CtiancityLoginDlg::OnButtonOK(IHTMLElement* /*pElement*/)
{
	CString strFucName="CheckForm";
	DISPID dispid;
	DISPPARAMS dispparams;
	memset(&dispparams, 0, sizeof dispparams);

	dispparams.cArgs=1;
	dispparams.rgvarg = new VARIANT[dispparams.cArgs];
	CComBSTR fromMFC=_T("from mfc");
	fromMFC.CopyTo(&dispparams.rgvarg[0].bstrVal);
	dispparams.rgvarg[0].vt = VT_BSTR;

	VARIANT varResult;

	ZeroMemory(&varResult,sizeof(varResult));
	EXCEPINFO excepInfo;
	memset(&excepInfo, 0, sizeof excepInfo);

	IHTMLDocument2* pDoc2;
	GetDHtmlDocument(&pDoc2);

	CallJSFunction(pDoc2,strFucName,dispparams,&varResult,&excepInfo,NULL);
	return S_OK;
}
//HRESULT CtiancityLoginDlg::OnTest(VARIANT& vStrFull,VARIANT& vStrName,VARIANT& vStrPassWord)
HRESULT CtiancityLoginDlg::OnTest(VARIANT& vStrFull,VARIANT& vStrPassWord)
{
	CComVariant varStr1(vStrFull),varStr2(vStrPassWord);
	varStr1.ChangeType(VT_BSTR);   
	varStr2.ChangeType(VT_BSTR);    
	USES_CONVERSION;    
	CString strMsg;   
	strMsg.Format(_T("varStr1:%s,varStr2:%s "),OLE2T(varStr1.bstrVal),OLE2T(varStr2.bstrVal));   
	LOGOIN* pLogin=new LOGOIN;
	ZeroMemory(pLogin,sizeof(LOGOIN));
	strcpy(pLogin->strFull,OLE2T(varStr1.bstrVal));
	strcpy(pLogin->strPassWord,OLE2T(varStr2.bstrVal));

	 EnterCriticalSection(&CLogin::g_cs);
	CLogin::g_ContextList.AddTail(pLogin);
	LeaveCriticalSection(&CLogin::g_cs);
	return S_OK;
}
