
// tiancityLoginDlg.h : ͷ�ļ�
//

#pragma once
#include "Login.h"
#include "afxcmn.h"

// CtiancityLoginDlg �Ի���
class CtiancityLoginDlg : public CDHtmlDialog
{

	
// ����
public:
	CtiancityLoginDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_TIANCITYLOGIN_DIALOG, IDH = IDR_HTML_TIANCITYLOGIN_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��

	HRESULT OnButtonOK(IHTMLElement *pElement);
	HRESULT OnTest(VARIANT& vStrFull,VARIANT& vStrName/*,VARIANT& vStrPassWord*/);

// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
	DECLARE_DHTML_EVENT_MAP()
	DECLARE_DISPATCH_MAP()
private:
	CLogin  m_aLogin[3];
	
public:
	CListCtrl m_list;
	CString m_msg1;
	CString m_msg2;
	CString m_msg3;
};
