#include "StdAfx.h"
#include "Login.h"
#include <winsock2.h>
#define TIME_OUT_TIME 20 //connect��ʱʱ��20��
CRITICAL_SECTION	CLogin::g_cs;
CList<LOGOIN*, LOGOIN* > CLogin::g_ContextList;
LONG  CLogin::bisChangeIP=0;
CLogin::CLogin()
{
	
	InitializeCriticalSection(&g_cs);
	int wVersionRequested = MAKEWORD( 1, 1 );
	WSADATA wsaData;
	int  err = WSAStartup( wVersionRequested, &wsaData );
	if ( err != 0 ) {
		OutputDebugString("WSAStartup Error!");
		return;
	}


	if ( LOBYTE( wsaData.wVersion ) != 1 ||
		HIBYTE( wsaData.wVersion ) != 1 ) {
			OutputDebugString("WSAStartup Error!");
			WSACleanup( );
			return; 
	}
}


CLogin::~CLogin(void)
{
	DeleteCriticalSection(&g_cs);
	WSACleanup();
}


BOOL CLogin::test(LOGOIN *pLogin)
 {
	 char *strYearMonth[4]={
		 "2012-03", 
		 "2012-02",
		 "2012-01",
		 "2011-12"
	 };
	 char strTempCookie[MAX_PATH]={0};
	 ZeroMemory(strTemp,MAX_PATH);
	 sockClient=socket(AF_INET,SOCK_STREAM,0);
	 int TimeOut=TIME_OUT_TIME;
	 ::setsockopt(sockClient,SOL_SOCKET,SO_SNDTIMEO,(char *)&TimeOut,sizeof(TimeOut));
	 ::setsockopt(sockClient,SOL_SOCKET,SO_RCVTIMEO,(char *)&TimeOut,sizeof(TimeOut));
	 SOCKADDR_IN addrSrv;
	 addrSrv.sin_addr.S_un.S_addr=inet_addr("114.80.72.208");
	 addrSrv.sin_family=AF_INET;
	 addrSrv.sin_port=htons(80);
	 
	 if(connect(sockClient,(SOCKADDR*)&addrSrv,sizeof(SOCKADDR))!=0)
	 {
        return LOGO_ERROR_SOCK;
	 }
	 
	 //-----------------------------------��ʼ�������ļ�------------��֤����---------------------------------------------
	  memset(strHander, '\0', 1024);
	strcat(strHander, "GET /login/login.aspx HTTP/1.1\r\n");
	strcat(strHander, "Accept: application/x-shockwave-flash, image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, */*\r\n");
	strcat(strHander, "Accept-Language: zh-ch\r\n");
	strcat(strHander, "Accept-Encoding: gzip, deflate\r\n");
	strcat(strHander, "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)\r\n");
	strcat(strHander, "Host: passport.tiancity.com\r\n");
	strcat(strHander, "Connection: Keep-Alive\r\n");
	strcat(strHander, "\r\n");
	int nError= send(sockClient,strHander,strlen(strHander)+1,0);
	if (WSAGetLastError()!=0)
	{
		return LOGO_ERROR_SOCK;                 //ͨ�Ŵ���
	}
	memset(strHtmlBuffer,0,1024*10);
	nTemp=0;
	while(1)
	{
		memset(recvBuf,0,1024);
		  int nCount=recv(sockClient,recvBuf,1024,0);
		  if (nCount<=0||nTemp>=1024*10)
		  {
			  break;
		  }else{
			 memcpy(strHtmlBuffer+nTemp,recvBuf,nCount);
			 nTemp+=nCount;
		  }
	 }
	//////////�õ�cookie��VIEWSTATE/////////////////////
	char*  lpTempBuffer=strstr(strHtmlBuffer,"Cookie");
	if (lpTempBuffer==NULL)
	{
	     return LOGO_ERROR_PAGE;
	}
	lpTempBuffer+=8;
	ZeroMemory(strCookie,1024);
	ZeroMemory(strVIEWSTATE,MAX_PATH);
	for(int i=0;i<MAX_PATH;i++){
		if (lpTempBuffer[i]==';')
		{
			break;
		}else{
			strCookie[i]=lpTempBuffer[i];
		}
	}

	//�õ�VIEWSTATE
	lpTempBuffer=strstr(strHtmlBuffer,"<th>��֤�룺</th>");
	if (lpTempBuffer!=NULL)
	{

		return LOGO_ERROR_CHECK;
	}
	strcpy(strTempCookie,strCookie);
	ZeroMemory(strVIEWSTATE,MAX_PATH);
	 strcpy(strVIEWSTATE,"%2FwEPDwULLTExNDM0NzYxNjZkGAEFHl9fQ29udHJvbHNSZXF1aXJlUG9zdEJhY2tLZXlfXxYBBQlidG5TdWJtaXQ%3D");
	
	 //------------------------------������֤���û���������-----------POST----------------------
	 int nHeaderCount=0;
	   memset(strHander, '\0', 1024);
	   ZeroMemory(strTemp,MAX_PATH);
	strcat(strHander, "POST /login/login.aspx HTTP/1.1\r\n");
	strcat(strHander, "Accept: application/x-shockwave-flash, image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, */*\r\n");
	strcat(strHander,"Referer: http://passport.tiancity.com/login/login.aspx\r\n");
	strcat(strHander, "Accept-Language: zh-ch\r\n");
	strcat(strHander,"Content-Type: application/x-www-form-urlencoded\r\n");
	strcat(strHander, "Accept-Encoding: gzip, deflate\r\n");
	strcat(strHander, "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)\r\n");
	strcat(strHander, "Host: passport.tiancity.com\r\n");
	strcat(strHander,"Content-Length: 250\r\n");
	strcat(strHander, "Connection: Keep-Alive\r\n");
	strcat(strHander,"Cache-Control: no-cache\r\n");
	ZeroMemory(strTemp,MAX_PATH);
	sprintf(strTemp,"Cookie: %s\r\n",strCookie);
	strcat(strHander,strTemp);
	strcat(strHander, "\r\n");
	ZeroMemory(strTemp,MAX_PATH);
	sprintf(strTemp,"__VIEWSTATE=%s&%s&btnSubmit.x=61&btnSubmit.y=16\r\n",
		strVIEWSTATE,pLogin->strPassWord);  
	strcat(strHander,strTemp);
	strcat(strHander, "\r\n");

	
	closesocket(sockClient);
	sockClient=socket(AF_INET,SOCK_STREAM,0);
	::setsockopt(sockClient,SOL_SOCKET,SO_SNDTIMEO,(char *)&TimeOut,sizeof(TimeOut));
	::setsockopt(sockClient,SOL_SOCKET,SO_RCVTIMEO,(char *)&TimeOut,sizeof(TimeOut));
	ZeroMemory(&addrSrv,sizeof(addrSrv));
	addrSrv.sin_addr.S_un.S_addr=inet_addr("114.80.72.208");
	addrSrv.sin_family=AF_INET;
	addrSrv.sin_port=htons(80);
	if(connect(sockClient,(SOCKADDR*)&addrSrv,sizeof(SOCKADDR))!=0)
	{
		return LOGO_ERROR_SOCK;
	}
	nError= send(sockClient,strHander,strlen(strHander)+1,0);
	if (WSAGetLastError()!=0)
	{
		return LOGO_ERROR_SOCK;                 //ͨ�Ŵ���
	}
	ZeroMemory(strHtmlBuffer,1024*10);
	nTemp=0;
	while(1)
	{
		memset(recvBuf,0,1024);
		int nCount=recv(sockClient,recvBuf,1024,0);
		 if (nCount<=0||nTemp>=1024*10)
		{
			break;
		}else{
			memcpy(strHtmlBuffer+nTemp,recvBuf,nCount);
			nTemp+=nCount;
		}
	}
	////////////�ҳ�TCSPUBLICJAUTHM=//////////////////
	lpTempBuffer=strstr(strHtmlBuffer,"TCSPUBLICJAUTHM");
	if (lpTempBuffer==NULL)
	{
		return LOGO_ERROR_PASSWORD;
	}
	strcat(strCookie,"; ");
	nTemp=strlen(strCookie);
	nTemp2=strlen(lpTempBuffer);
	ZeroMemory(strTemp,MAX_PATH);
	if (lpTempBuffer!=NULL)
	{
		
			for(int i=0;i<nTemp2;i++){
				if (lpTempBuffer[i]==';')
				{
					break;
				}else{
					strCookie[i+nTemp]=lpTempBuffer[i];
				}
			}
	}      
	
	//-----------------------------------��ʼ�������ļ�--------------�ѵ�¼����-------------------------------------------
    memset(strHander, '\0', 1024);
	strcat(strHander, "GET /login/default.aspx HTTP/1.1\r\n");
	strcat(strHander, "Accept: application/x-shockwave-flash, image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, */*\r\n");
	strcat(strHander, "Accept-Language: zh-cn\r\n");
	strcat(strHander, "Accept-Encoding: gzip, deflate\r\n");
	strcat(strHander, "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)\r\n");
	strcat(strHander, "Host: passport.tiancity.com\r\n");
	strcat(strHander, "Connection: Keep-Alive\r\n");
	strcat(strHander,"Cookie: ");
	strcat(strHander,strCookie);
	strcat(strHander,"\r\n");
	strcat(strHander,"\r\n");
	closesocket(sockClient);
	sockClient=socket(AF_INET,SOCK_STREAM,0);
	::setsockopt(sockClient,SOL_SOCKET,SO_SNDTIMEO,(char *)&TimeOut,sizeof(TimeOut));
	::setsockopt(sockClient,SOL_SOCKET,SO_RCVTIMEO,(char *)&TimeOut,sizeof(TimeOut));
	ZeroMemory(&addrSrv,sizeof(addrSrv));
	addrSrv.sin_addr.S_un.S_addr=inet_addr("114.80.72.208");
	addrSrv.sin_family=AF_INET;
	addrSrv.sin_port=htons(80);
	if(connect(sockClient,(SOCKADDR*)&addrSrv,sizeof(SOCKADDR))!=0)
	{
		return LOGO_ERROR_SOCK;
	}
	nError= send(sockClient,strHander,strlen(strHander)+1,0);
	if (WSAGetLastError()!=0)
	{
		return LOGO_ERROR_SOCK;                 //ͨ�Ŵ���
	}
	ZeroMemory(strHtmlBuffer,1024*10);
	nTemp=0;
	while(1)
	{
		memset(recvBuf,0,1024);
		int nCount=recv(sockClient,recvBuf,1024,0);
		if (nCount<=0||nTemp>=1024*10)
		{
			break;
		}else{
			memcpy(strHtmlBuffer+nTemp,recvBuf,nCount);
			nTemp+=nCount;
		}
	}
	
	//-----------------------------------��ʼ�������ļ�-------------���֡����--------------------------------------------
	//TCSPUBLICJAUTHM=
	memset(strHander, '\0', 1024);
	strcpy(strHander,strCookie);
	lpTempBuffer=strstr(strHander,"TCSPUBLICJAUTHM");
	ZeroMemory(strCookie,1024);
	strcpy(strCookie,lpTempBuffer);

	memset(strHander, '\0', 1024);
	strcat(strHander, "GET /Wallet/UserService.aspx HTTP/1.1\r\n");
	strcat(strHander, "Accept: */*\r\n");
	strcat(strHander, "Referer: http://passport.tiancity.com/login/default.aspx\r\n");
	strcat(strHander, "Accept-Language: zh-cn\r\n");
	strcat(strHander, "Accept-Encoding: gzip, deflate\r\n");
	strcat(strHander, "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)\r\n");
	strcat(strHander, "Host: pay.tiancity.com\r\n");
	strcat(strHander, "Connection: Keep-Alive\r\n");
	strcat(strHander,"Cookie: ");
	strcat(strHander,strCookie);
	strcat(strHander,"\r\n");
	strcat(strHander,"\r\n");

	closesocket(sockClient);
	sockClient=socket(AF_INET,SOCK_STREAM,0);
	::setsockopt(sockClient,SOL_SOCKET,SO_SNDTIMEO,(char *)&TimeOut,sizeof(TimeOut));
	::setsockopt(sockClient,SOL_SOCKET,SO_RCVTIMEO,(char *)&TimeOut,sizeof(TimeOut));
	ZeroMemory(&addrSrv,sizeof(addrSrv));
	addrSrv.sin_addr.S_un.S_addr=inet_addr("114.80.72.214");
	addrSrv.sin_family=AF_INET;
	addrSrv.sin_port=htons(80);
	if(connect(sockClient,(SOCKADDR*)&addrSrv,sizeof(SOCKADDR))!=0)
	{
		return LOGO_ERROR_SOCK;
	}
	nError= send(sockClient,strHander,strlen(strHander)+1,0);
	if (WSAGetLastError()!=0)
	{
		return LOGO_ERROR_SOCK;                 //ͨ�Ŵ���
	}
	ZeroMemory(strHtmlBuffer,1024*10);
	nTemp=0;
	while(1)
	{
		memset(recvBuf,0,1024);
		int nCount=recv(sockClient,recvBuf,1024,0);
		if (nCount<=0||nTemp>=1024*10)
		{
			break;
		}else{
			memcpy(strHtmlBuffer+nTemp,recvBuf,nCount);
			nTemp+=nCount;
		}
	}
	//////////////�õ��û����֣����////////////////////
	//TCSPUBLICJAUTHM=
	lpTempBuffer=strstr(strHtmlBuffer,"<th>������</th>");
	if (lpTempBuffer==NULL)
	{
		return LOGO_ERROR_PAGE;
	}
	lpTempBuffer=strstr(lpTempBuffer,"fred");
	if (lpTempBuffer!=NULL)
	{
		lpTempBuffer+=6;
		for(int i=0;i<20;i++){
			if (lpTempBuffer[i]=='<')
			{
				break;
			}else{
				pLogin->strYuE[i]=lpTempBuffer[i];
			}
		}
	}
	//////////////
	lpTempBuffer=strstr(strHtmlBuffer,"<th>���û��֣�</th>");
	if (lpTempBuffer==NULL)
	{
		return LOGO_ERROR_PAGE;
	}
	lpTempBuffer=strstr(lpTempBuffer,"fred");
	if (lpTempBuffer!=NULL)
	{
		lpTempBuffer+=6;
		for(int i=0;i<20;i++){
			if (lpTempBuffer[i]=='<')
			{
				break;
			}else{
				pLogin->strJiFen[i]=lpTempBuffer[i];
			}
		}
	}
	//----------------------------------------��ѯ��ʷ��¼-----------------------------------------
	//����Cookie
	for (int i=0;i<4;i++)
	{
		memset(strHander, '\0', 1024);
		strcpy(strHander,strCookie);
		ZeroMemory(strCookie,1024);
		sprintf(strCookie,"%s;ValidateCode=VNum=b11769c5998f49df;%s",strTempCookie,strHander);
		memset(strHander, '\0', 1024);
		sprintf(strHander, "GET /Wallet/TransactionList.aspx?year_month=%s HTTP/1.1\r\n",strYearMonth[i]);
		strcat(strHander, "Accept: application/x-shockwave-flash, image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, */*\r\n");
		strcat(strHander, "Accept-Language: zh-cn\r\n");
		strcat(strHander, "Accept-Encoding: gzip, deflate\r\n");
		strcat(strHander, "User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)\r\n");
		strcat(strHander, "Host: pay.tiancity.com\r\n");
		strcat(strHander, "Connection: Keep-Alive\r\n");
		strcat(strHander,"Cookie: ");
		strcat(strHander,strCookie);
		strcat(strHander,"\r\n");
		strcat(strHander,"\r\n");

		closesocket(sockClient);
		sockClient=socket(AF_INET,SOCK_STREAM,0);
		::setsockopt(sockClient,SOL_SOCKET,SO_SNDTIMEO,(char *)&TimeOut,sizeof(TimeOut));
		::setsockopt(sockClient,SOL_SOCKET,SO_RCVTIMEO,(char *)&TimeOut,sizeof(TimeOut));
		ZeroMemory(&addrSrv,sizeof(addrSrv));
		addrSrv.sin_addr.S_un.S_addr=inet_addr("114.80.72.214");
		addrSrv.sin_family=AF_INET;
		addrSrv.sin_port=htons(80);
		if(connect(sockClient,(SOCKADDR*)&addrSrv,sizeof(SOCKADDR))!=0)
		{
			return LOGO_ERROR_SOCK;
		}
		nError= send(sockClient,strHander,strlen(strHander)+1,0);
		if (WSAGetLastError()!=0)
		{
			return LOGO_ERROR_SOCK;                 //ͨ�Ŵ���
		}
		ZeroMemory(strHtmlBuffer,1024*10);
		nTemp=0;
		while(1)
		{
			memset(recvBuf,0,1024);
			int nCount=recv(sockClient,recvBuf,1024,0);
			if (nCount<=0||nTemp>=1024*10)
			{
				break;
			}else{
				memcpy(strHtmlBuffer+nTemp,recvBuf,nCount);
				nTemp+=nCount;
			}
		}
		while(1)
		{
			memset(recvBuf,0,1024);
			int nCount=recv(sockClient,recvBuf,1024,0);
			if (nCount<=0||nTemp>=1024*10)
			{
				break;
			}else{
				memcpy(strHtmlBuffer+nTemp,recvBuf,nCount);
				nTemp+=nCount;
			}
		}
		/////////////////////����//////////////
		lpTempBuffer=strstr(strHtmlBuffer,"����Ӣ�۴�");
		nTemp=0;
		if (lpTempBuffer!=NULL)
		{
			lpTempBuffer+=13;
			for(int j=0;j<MAX_PATH;j++){
				if (lpTempBuffer[j]=='-')
				{
					break;
				}else{
					pLogin->strAddress[j]=lpTempBuffer[j];
				}
			}
			break;            //���ﷵ��
		}
	}

	 printf("%s\n",recvBuf);
	 closesocket(sockClient);

	 return LOGO_OK;
 }

 void CLogin::Start(void)
 {
	 (HANDLE)CreateThread(NULL,	0, (LPTHREAD_START_ROUTINE)ThreadFunc,(void*) this, 0,0);	
 }


 DWORD CLogin::ThreadFunc(LPVOID lParam)
 {
	 CLogin* pThis=(CLogin*)lParam;
	 DWORD dwTemp;
	  char strMessage[MAX_PATH];

	HANDLE hOpenFile = (HANDLE)CreateFileA("123.txt",GENERIC_WRITE,0,NULL,OPEN_ALWAYS,NULL,NULL);  
	char strEntry[4]={"\r\n\0"};
	 while(1)
	 {
		 while (g_ContextList.IsEmpty())
		 {
			 Sleep(1);
		 }
		 EnterCriticalSection(&CLogin::g_cs);
		LOGOIN *pLogin=(LOGOIN*)g_ContextList.RemoveHead();
		 LeaveCriticalSection(&CLogin::g_cs);
		 if (pLogin==NULL)
		 {
			 continue;
		 }
		 try
		 {
_start_logoin:
			  BOOL bStact=pThis->test(pLogin);
			 if (bStact==LOGO_OK)                                        //��֤�ɹ�
			 {
				SetWindowText(pThis->m_hWnd,"��¼�ɹ�д���ļ�!");
				OutputDebugString("��¼�ɹ�д���ļ�!");
    			pThis->m_pList->InsertItem(0,pLogin->strFull);
				pThis->m_pList->SetItemText(0,1,pLogin->strYuE);
				pThis->m_pList->SetItemText(0,2,pLogin->strJiFen);
				pThis->m_pList->SetItemText(0,3,pLogin->strAddress);
			 }else if (bStact==LOGO_ERROR_CHECK)                        //��Ҫ��֤��
			 {
				 SetWindowText(pThis->m_hWnd,"��Ҫ��֤��!");
				 OutputDebugString("��Ҫ��֤��!");
				 if (bisChangeIP==FALSE) 
				 {
					  int i=g_ContextList.GetCount();
					  InterlockedIncrement(&bisChangeIP);
					  i=g_ContextList.GetCount();
					  i++;
					  InterlockedDecrement(&bisChangeIP);
				 }
				
				 goto _start_logoin;
			 }else if (bStact==LOGO_ERROR_PAGE)                       //ҳ������ʧ��
			 {
				  SetWindowText(pThis->m_hWnd,"����ҳ��ʧ��!");
				  OutputDebugString("����ҳ��ʧ��!");
				  goto _start_logoin;
			 }
			 else if (bStact==LOGO_ERROR_SOCK)                       //ͨ�Ŵ���
			 {
				 ZeroMemory(strMessage,MAX_PATH);
				 sprintf(strMessage,"�Ŵ��� socket=%ld\n", WSAGetLastError());//�Լ���Ϲ���
				 SetWindowText(pThis->m_hWnd,strMessage);
				 OutputDebugString(strMessage);
				 goto _start_logoin;
			 }else if (bStact==LOGO_ERROR_PASSWORD)
			 {
				  SetWindowText(pThis->m_hWnd,"�û������������!");
				  OutputDebugString("�û������������!");
			 }
  			 delete pLogin;
			 pLogin=NULL;
		 }

		 catch (CMemoryException* e)
		 {
		 	
		 }
		 catch (CFileException* e)
		 {
		 }
		 catch (CException* e)
		 {
		 }
		

	 }
	 CloseHandle(hOpenFile);
	 return 0;
 }
