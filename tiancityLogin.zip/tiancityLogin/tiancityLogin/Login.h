#pragma once

struct LOGOIN 
{
	char strFull[MAX_PATH];
	char strPassWord[MAX_PATH];
	char strYuE[20];
	char strJiFen[20];
	char strAddress[MAX_PATH];

};

enum
{
	LOGO_OK=1,
	LOGO_ERROR_SOCK,                //ͨ�Ŵ���
	LOGO_ERROR_PAGE,               //�õ�ҳ��ʧ��
	LOGO_ERROR_PASSWORD,                 //�û����������
	LOGO_ERROR_CHECK,                 //��Ҫ��֤��



};
class CLogin
{
public:
	CLogin(void);
	~CLogin(void);
	BOOL test(LOGOIN *pLogin);
	void Start(void);
	static DWORD ThreadFunc(LPVOID lParam);
	static CList<LOGOIN*, LOGOIN* > g_ContextList;
	static CRITICAL_SECTION	g_cs;
	static LONG  bisChangeIP;          //�Ƿ����IP 
private:
	WORD wVersionRequested;
	WSADATA wsaData;
	int err;
	char strHander[1024];
	char strMessage[1024];
	char strHtmlBuffer[1024*10];
	char recvBuf[1024];
	char strCookie[1024];
	char strVIEWSTATE[MAX_PATH];
	char strTemp[MAX_PATH];
	DWORD   dwNumberOfBytesRead;        // ���������ش�С  
	int nTemp,nTemp2;
	SOCKET sockClient;
public:
	CListCtrl *m_pList;
	CString *m_pMsg;
	HWND     m_hWnd;
	 
};

