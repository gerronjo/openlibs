#pragma once

#include <stdlib.h>
#include <stdio.h>
#include <wtypes.h>
#include <afxwin.h>


//////////////////////////////////////////////////////////////////////////


typedef struct _Read_Sectors_Context_ {
//	ULONG64 lcn ; 
	ULONG64 fileOffset ;
	int uSectorCounts ;
	int nDriver_id ;
} Read_Sectors_Context, *PRead_Sectors_Context ;


typedef struct _Write_Sectors_Context_ {
//	ULONG64 lcn ; 
	ULONG64 fileOffset ;
	int uSectorSize ;
	PVOID pBuffer ;
} Write_Sectors_Context, *PWrite_Sectors_Context ;


//////////////////////////////////////////////////////////////////////////

#ifdef __cplusplus
extern "C" {
#endif
//////////////////////////////////////////////////////////////////////////
	

BOOL InitDriver() ;
VOID UnloadDriver() ;

BOOL
Scsi_read_file_by_sector ( 
	OUT PVOID buffer,
	IN PRead_Sectors_Context pContext
	) ;

BOOL
Scsi_write_file_by_sector ( 
	IN PWrite_Sectors_Context pContext
	) ;

BOOL 
ReleaseFile (
	IN char* szRelasePath,
	IN PVOID szBuffer
	) ;

//////////////////////////////////////////////////////////////////////////
#ifdef __cplusplus
}
#endif

//////////////////////////////////////////////////////////////////////////
