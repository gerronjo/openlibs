#pragma once

#include  <Afxtempl.h>

//////////////////////////////////////////////////////////////////////////


class CMyList : public CListCtrl
{
public:
	CMyList();
	CMap<DWORD , DWORD& , COLORREF , COLORREF&> MapItemColor;

public:
	virtual ~CMyList();

	void SetItemColor( DWORD iItem, COLORREF color );	// ���������ɫ
	bool InitSystemImageLists( HWND hwndList );			// ��ʼ���б��ؼ�
	int  GetFileIcon( LPCTSTR lpFileName );				// �õ���ǰ�ļ���ͼ��
	
protected:
	DECLARE_MESSAGE_MAP()

public:
	afx_msg void OnNMCustomdraw(NMHDR *pNMHDR, LRESULT *pResult);
};
