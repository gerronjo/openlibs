#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <afxwin.h>
#include <stddef.h>

#include "misc.h"
#include "logging.h"

//////////////////////////////////////////////////////////////////////////

void *ntfs_calloc(size_t size)
{
	void *p;
	
	p = calloc(1, size);
	if (!p)
		ntfs_log_perror("Failed to calloc %lld bytes", (LONG64)size);
	return p;
}


void *ntfs_malloc(size_t size)
{
	void *p;
	
	p = malloc(size);
	if (!p)
		ntfs_log_perror("Failed to malloc %lld bytes", (LONG64)size);
	return p;
}

