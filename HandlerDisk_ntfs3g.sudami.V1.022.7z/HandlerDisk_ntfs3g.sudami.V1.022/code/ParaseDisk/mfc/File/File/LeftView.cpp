/***************************************************************************************
* AUTHOR : sudami [sudami@163.com]
* TIME   : 2009/03/24 [24:3:2009 - 13:51]
* MODULE : d:\Program\R0\Coding\���̲���\code\ParaseDisk\mfc\File\File\LeftView.cpp
* 
* Command: 
*   
*   
*
* Description:
*   
*                        
*
***
* Copyright (c) 2008 - 2010 sudami.
* Freely distributable in source or binary for noncommercial purposes.
* TAKE IT EASY,JUST FOR FUN.
*
****************************************************************************************/

#include "stdafx.h"
#include "File.h"
#include "FileDoc.h"
#include "LeftView.h"
#include "FileView.h"
#include "MainFrm.h"

#include "LoadDriver/CLoadDriver_2.h"
#include "ntfs_header.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#pragma warning( disable: 4244 4996 )

//////////////////////////////////////////////////////////////////////////


extern CDriver* g_drv ;

#define MYCOMPUTER "My Computer"

char g_szOldPartition = NULL  ;
int g_currentSubFileCounts = 0 ;
HTREEITEM g_current_hItem ;
char  g_szCurrentParantPath[MAX_PATH] = "" ;


CLeftView g_CLeftView_class ;
CFileDoc* pDoc = NULL ;

/////////////////////////////////////////////////////////////////////////////
// CLeftView

IMPLEMENT_DYNCREATE(CLeftView, CTreeView)

BEGIN_MESSAGE_MAP(CLeftView, CTreeView)

	ON_WM_DESTROY()
	ON_NOTIFY_REFLECT(TVN_ITEMEXPANDING, OnItemexpanding)
	ON_NOTIFY_REFLECT(TVN_SELCHANGING, OnSelchanging)
	ON_WM_RBUTTONDBLCLK()

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLeftView construction/destruction

CLeftView::CLeftView()
{
}

CLeftView::~CLeftView()
{
}

BOOL CLeftView::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.style |= TVS_HASBUTTONS | TVS_LINESATROOT | TVS_HASLINES;

	return CTreeView::PreCreateWindow(cs);
}


/////////////////////////////////////////////////////////////////////////////
// CLeftView drawing

void CLeftView::OnDraw(CDC* pDC)
{
	CDriveExplorerDoc* pDoc = GetDocument();
}



void CLeftView::OnInitialUpdate()
{
	CTreeView::OnInitialUpdate();
	CTreeView::OnInitialUpdate();
	m_pImageList = new CImageList();
	CWinApp* pApp = AfxGetApp();

	m_pImageList->Create(16, 16, ILC_COLOR8 | ILC_MASK,  9, 9);
	m_pImageList->Add(pApp->LoadIcon(ICO_CDDRV));
	m_pImageList->Add(pApp->LoadIcon(IDI_ICON3));
	m_pImageList->Add(pApp->LoadIcon(IDI_ICON4));
	m_pImageList->Add(pApp->LoadIcon(IDI_ICON2));
	m_pImageList->Add(pApp->LoadIcon(ICO_MYCOMP));
	m_pImageList->Add(pApp->LoadIcon(ICO_OPENFLD));		

	GetTreeCtrl().SetImageList( m_pImageList , TVSIL_NORMAL );
	GetTreeCtrl().ModifyStyle( 0, TVS_HASLINES | TVS_HASBUTTONS | TVS_SHOWSELALWAYS | TVS_SINGLEEXPAND | TVSIL_NORMAL );

	HTREEITEM hParent = GetTreeCtrl().InsertItem( MYCOMPUTER, ILI_MYCOMP, ILI_MYCOMP );

	InitTreeView( hParent );
	GetTreeCtrl().Expand( hParent, TVE_EXPAND ); 

	if ( NULL == g_drv ) 
	{
		if ( FALSE == InitDriver() ) {
			printf( "error! Can't Load Driver \n" );
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
// CLeftView diagnostics

#ifdef _DEBUG
void CLeftView::AssertValid() const
{
	CTreeView::AssertValid();
}

void CLeftView::Dump(CDumpContext& dc) const
{
	CTreeView::Dump(dc);
}

CDriveExplorerDoc* CLeftView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CFileDoc)));
	return (CDriveExplorerDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CLeftView message handlers

void CLeftView::InitTreeView( HTREEITEM hParent )
{
	int nPos = 0;
	UINT nCount = 0;
	CString cTmp, strDrive = "?:\\";
	DWORD dwDriveList = ::GetLogicalDrives ();

	while ( dwDriveList ) 
	{
		if ( dwDriveList & 1 ) 
		{
			cTmp = strDrive;
			strDrive.SetAt (0, 0x41 + nPos);
			if ( AddDrives(strDrive , hParent) )
				nCount++;
		}

		dwDriveList >>= 1 ;
		nPos++ ;
	}

	return;
}


//
//
//

BOOL CLeftView::AddDrives(CString strDrive, HTREEITEM hParent)
{
	HTREEITEM hItem;
	UINT nType = ::GetDriveType ((LPCTSTR) strDrive);
	UINT nDrive = (UINT) strDrive[0] - 0x41;

	switch (nType) {

	case DRIVE_REMOVABLE: // ���ƶ�����
		strDrive = strDrive;
		hItem = GetTreeCtrl().InsertItem(strDrive, ILI_FLOPPYDRV, ILI_FLOPPYDRV, hParent);
		if ( HasSubdirectory( strDrive ) )
		{
			AddDummyNode( hItem, GetTreeCtrl()  );
		}

		break;

	case DRIVE_FIXED:
		strDrive=strDrive;
		hItem = GetTreeCtrl().InsertItem(strDrive,  ILI_DRIVE, ILI_DRIVE, hParent);
		if ( HasSubdirectory( strDrive ) )
		{
			AddDummyNode( hItem, GetTreeCtrl() );
		}

		break;

	case DRIVE_REMOTE: // ����������
		hItem = GetTreeCtrl().InsertItem(strDrive, ILI_DRIVE, ILI_DRIVE, hParent);
		if ( HasSubdirectory( strDrive ) )
		{
			AddDummyNode( hItem, GetTreeCtrl() );
		}

		break;

	case DRIVE_CDROM:	// ���̽���
		strDrive=strDrive;
		hItem = GetTreeCtrl().InsertItem(strDrive, ILI_CDDRV, ILI_CDDRV, hParent);
		if ( HasSubdirectory( strDrive ) )
		{
			AddDummyNode( hItem, GetTreeCtrl() );
		}

		break;

	case DRIVE_RAMDISK:
		hItem = GetTreeCtrl().InsertItem(strDrive, ILI_CDDRV, ILI_CDDRV, hParent);
		if ( HasSubdirectory( strDrive ) )
		{
			AddDummyNode( hItem, GetTreeCtrl() );
		}
		break;

	default:
		return FALSE ;
	}

	return TRUE ;
}


//
// �жϵ�ǰ·���Ƿ�Ϊ "�ļ���"
//
BOOL CLeftView::HasSubdirectory(CString &strPathName)
{
	HANDLE hFind;
	WIN32_FIND_DATA fd;
	BOOL bResult = FALSE;

	CString strFileSpec = strPathName;
	if (strFileSpec.Right (1) != "\\")
		strFileSpec += "\\";
	strFileSpec += "*.*";

	if ((hFind = ::FindFirstFile ((LPCTSTR) strFileSpec, &fd)) !=
		INVALID_HANDLE_VALUE) {
			do {
				if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
					CString strFileName = (LPCTSTR) &fd.cFileName;
					if ((strFileName != ".") && (strFileName != ".."))
						bResult = TRUE;
				}
			} while (::FindNextFile (hFind, &fd) && !bResult);
			::FindClose (hFind);
	}

	return bResult;
}


//
// �����ļ���,����һ�� + ��
//
void CLeftView::AddDummyNode(HTREEITEM hItem, CTreeCtrl& treeCtrl)
{
//	GetTreeCtrl().InsertItem ("", 0, 0, hItem);
	treeCtrl.InsertItem ("", 0, 0, hItem);

	return ;
}


//
// �ӿؼ��ϵõ���ǰ�������ļ�ȫ·��
//
CString CLeftView::GetPathFromItem(HTREEITEM hItem)
{
	CString strPathName;
	while ( hItem != NULL ) 
	{
		CString string = GetTreeCtrl().GetItemText( hItem );
		if ( (string.Right (1) != "\\") && !strPathName.IsEmpty () ) {
			string += "\\" ;
		}

		strPathName = string + strPathName;
		hItem = GetTreeCtrl().GetParentItem (hItem);
	}


	if(strPathName.Left(11) == MYCOMPUTER && strPathName.GetLength() > 11)
		strPathName = strPathName.Mid(12);

	return strPathName;
}


//
// ��⵱ǰ·���Ƿ�Ϸ�
//
BOOL CLeftView::IsPathValid(CString &strPathName)
{
	if (strPathName.GetLength () == 3)
		return TRUE;

	HANDLE hFind;
	WIN32_FIND_DATA fd;
	BOOL bResult = FALSE;

	if ((hFind = ::FindFirstFile ((LPCTSTR) strPathName, &fd)) != INVALID_HANDLE_VALUE) 
	{
		// ����������ļ�,�������ļ���,���سɹ�
		if ( fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY )
			bResult = TRUE;

		::CloseHandle (hFind);
	}

	return bResult;
}


//
//
//
BOOL CLeftView::IsMediaValid(CString &strPathName)
{
	UINT nDriveType = GetDriveType ((LPCTSTR) strPathName);

	if ( (nDriveType != DRIVE_REMOVABLE) && (nDriveType != DRIVE_CDROM) )
		return TRUE;
	else
		return FALSE;
}


//
// �õ����οؼ��е�ǰ�ڵ�ĸ�. hRoot
//
HTREEITEM CLeftView::GetDriveNode(HTREEITEM hItem)
{
	HTREEITEM hParent;
	
	do 
	{
		hParent = GetTreeCtrl().GetParentItem (hItem);
		if ( hParent != NULL )
			hItem = hParent ;

	} while ( hParent != NULL );

	return hItem;
}


//
// ɾ�����οؼ��е�ǰ�ڵ��°����������ӽڵ�
//
UINT CLeftView::DeleteChildren(HTREEITEM hItem)
{
	UINT nCount = 0;
	HTREEITEM hChild = GetTreeCtrl().GetChildItem (hItem);

	while ( hChild != NULL ) 
	{
		HTREEITEM hNextItem = GetTreeCtrl().GetNextSiblingItem (hChild);
		GetTreeCtrl().DeleteItem (hChild);
		hChild = hNextItem;
		nCount++ ;
	}

	return nCount;

}



//
//
//

UINT CLeftView::AddDirectoryNodes(HTREEITEM hItem, CString &strPathName)
{
	PDIRECTORY_INFO   temp = NULL ;
	char  a[MAX_PATH] = "", b[2] = "" ;
	CString strFileSpec = strPathName;

	g_current_hItem = hItem ;
//	m_cTreeCtrl = (CTreeCtrl) GetTreeCtrl() ;
	CTreeCtrl& treeCtrl = GetTreeCtrl(); 

	if ( strFileSpec.Right (1) != "\\" ) { strFileSpec += "\\"; }

	strcpy( a, strFileSpec.GetBuffer(strFileSpec.GetLength()) );
	strncpy( b, a, sizeof(char) ); // ������һ����ĸ,���̷���
	strcpy( g_szCurrentParantPath, a ); // ���浱ǰ�ĸ�·����ȫ�ֱ�����

	if ( (NULL == g_szOldPartition) || (b[0] != g_szOldPartition) ) // �����ǵ�һ��,���̷���
	{
		// �򿪵�ǰ�̷�
		g_szOldPartition = b[0] ;
		ntfs_open( b, 0 );
	}

	CWaitCursor wait;
	pDoc = (CFileDoc*) GetDocument();

	// ɾ���б��ؼ��е�������
	pDoc->m_MTListView->DeleteAllItems();
	pDoc->m_MTListView->SetPath( strFileSpec,hDevice );

	// ����֮
	ntfs_enumerate_dir_ex( a, treeCtrl );

	/*
	for(ULONG i=0;i<num;i++)
	{
		str.Format("%s",temp[i].FileName);
		str=str1+str; // str�����˵�ǰ�ļ���ȫ·��

		if(PathIsDirectory(str))
		{
			if(strcmp(temp[i].FileName,"."))
			{
				if(strcmp(temp[i].FileName,".."))
				{
					// �����οؼ��в��뵱ǰ�оٵ����ļ��е�����
					HTREEITEM hChild =
						GetTreeCtrl().InsertItem ((LPCTSTR) temp[i].FileName,//&fd.cFileName,
						ILI_CLSDFLD , ILI_OPENFLD , hItem , TVI_SORT);

					CString strNewPathName = strPathName;
					if (strNewPathName.Right (1) != "\\")
						strNewPathName += "\\";

					strNewPathName += (LPCTSTR) temp[i].FileName ;
					SetButtonState (hChild, strNewPathName); // �����ļ��а������ļ�,��Ҫ�໭��+��	
				}
			}
		}
		else
		{
			// ���ļ�����뵽�б��ؼ���
			b.DirectoryInfo=temp[i];
			b.path=str1;
			pDoc->m_MTListView->AddToListView(&b);	
		}
	} 
	*/

	return g_currentSubFileCounts ;
}


//
// �����οؼ��иýڵ�����Ŀ¼,��໭һ�� + ��
//
void CLeftView::SetButtonState(HTREEITEM hItem, CString &strPathName, CTreeCtrl& treeCtrl)
{
	if ( HasSubdirectory (strPathName) )
		AddDummyNode( hItem, treeCtrl );
}


//
// �жϵ�ǰ�ڵ��Ƿ�Ϊ���ڵ�
//
BOOL CLeftView::IsDriveNode(HTREEITEM hItem)
{
	return (GetTreeCtrl().GetParentItem (hItem) == NULL) ? TRUE : FALSE;
}


//
// չ��һ���ڵ�,չʾ�����°����������ӽڵ�
//
void CLeftView::OnItemexpanding(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR ;

	// �õ���ǰ�ڵ��ȫ·��
	HTREEITEM hItem = pNMTreeView->itemNew.hItem ;
	CString strPathName = GetPathFromItem( hItem );

	// ���ƶ�����, �����ôչ��...
	if ( !IsMediaValid (strPathName) ) 
	{
		HTREEITEM hRoot = GetDriveNode( hItem );
		GetTreeCtrl().Expand( hRoot, TVE_COLLAPSE );
		DeleteChildren( hRoot );
		AddDummyNode ( hRoot, GetTreeCtrl() );
		*pResult = TRUE;
		return;
	}

	// ����ǰ����ڵ�ʵ���Ѿ���������. ֻ���ڿؼ���û��ˢ��, ��ô�㵽��ʱ,Ӧɾ��
	if (!IsPathValid (strPathName)) 
	{
		if(strPathName != MYCOMPUTER && strPathName != "")
		{
			GetTreeCtrl().DeleteItem (hItem);
			*pResult = TRUE;
			return;
		}
	}

	CWaitCursor wait;
	
	if ( pNMTreeView->action == TVE_EXPAND ) 
	{
		// ��Ҫչ���ڵ�
		if( strPathName != MYCOMPUTER )
		{
			DeleteChildren (hItem);

			if ( !AddDirectoryNodes( hItem, strPathName ) )
				*pResult = TRUE ;
		}
	}
	else 
	{	
		// ��Ҫ �����ڵ�
		if( strPathName != MYCOMPUTER )
		{
			DeleteChildren (hItem);
			if (IsDriveNode (hItem))
				AddDummyNode (hItem, GetTreeCtrl());
			else
				SetButtonState (hItem, strPathName, GetTreeCtrl());
		}
	}

	m_LocalPath = strPathName ;
	*pResult = 0 ;

	return ;
}


//
// չ�����οؼ��ĸ��ڵ�, ������...
//
void CLeftView::OnSelchanging(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_TREEVIEW* pNMTreeView = (NM_TREEVIEW*)pNMHDR;

	HTREEITEM hItem = pNMTreeView->itemNew.hItem;

	CString strPathName = GetPathFromItem (hItem);
	*pResult = FALSE;

	if(strPathName == MYCOMPUTER)
		return;

	CWaitCursor wait;

	if ( !AddDirectoryNodes( hItem, strPathName ) )
		*pResult = TRUE;

	m_LocalPath = strPathName;
	*pResult = 0;
}


//
// ����
//
void CLeftView::OnDestroy() 
{
	CTreeView::OnDestroy();

	if( m_pImageList != NULL )
		m_pImageList = NULL ;

	delete m_pImageList ;
}



void CLeftView::OnRButtonDblClk(UINT nFlags, CPoint point) 
{
	CTreeView::OnRButtonDblClk(nFlags, point);
}



void CLeftView::Insert_tree_list_node (
	LPCTSTR szName,
	int a,
	int b,
	BOOL bIsDiretory,
	CTreeCtrl& treeCtrl
	)
{
	

	if ( TRUE == bIsDiretory ) 
	{
		// ���ļ���,���뵽���οؼ���
	
	//	HTREEITEM hChild = GetTreeCtrl().InsertItem ((LPCTSTR) szName, a, b, g_current_hItem , TVI_SORT);
		HTREEITEM hChild = treeCtrl.InsertItem ((LPCTSTR) szName, a, b, g_current_hItem , TVI_SORT);

		CString strNewPathName = (LPCTSTR) g_szCurrentParantPath ;

		if (strNewPathName.Right (1) != "\\")
			strNewPathName += "\\";

		strNewPathName += (LPCTSTR) szName ;
		SetButtonState( hChild, strNewPathName, treeCtrl ); // �����ļ��а������ļ�,��Ҫ�໭��+��	
	} 
	else 
	{
		// ���ļ�,���뵽�б��ؼ���
		DIRECTORY_INFO_EX fileInfo ;

		fileInfo.DirectoryInfo.FileName = (char*)(LPSTR)(LPCTSTR) szName  ;
		fileInfo.FatherPath				= (LPCTSTR) g_szCurrentParantPath ;

		pDoc->m_MTListView->AddToListView( &fileInfo );	
	}
	
	return ;
}

