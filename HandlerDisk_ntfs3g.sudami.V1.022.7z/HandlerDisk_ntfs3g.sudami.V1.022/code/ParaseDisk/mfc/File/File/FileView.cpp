// FileView.cpp : CFileView ���ʵ��
//

#include "stdafx.h"
#include "File.h"

#include "FileDoc.h"
#include "FileView.h"

#include "ntfs_header.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


#pragma warning( disable: 4244 4996 )

//////////////////////////////////////////////////////////////////////////

CMyList   *ProcessList ;


//////////////////////////////////////////////////////////////////////////

// CFileView

IMPLEMENT_DYNCREATE(CFileView, CListView)

BEGIN_MESSAGE_MAP(CFileView, CListView)
	ON_NOTIFY_REFLECT(NM_RCLICK, OnRclick)
	ON_COMMAND(IDM_DISK_DELETE, &CFileView::OnDiskDelete)
	ON_COMMAND(IDR_SYS_DELETE, &CFileView::OnSysDelete)
	ON_WM_SIZE()
END_MESSAGE_MAP()

// CFileView ����/����

CFileView::CFileView()
{
	m_List = (CMyList*)&GetListCtrl() ;
	index=0;
}

CFileView::~CFileView()
{
}



BOOL CFileView::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.style |= LVS_REPORT ; // ���б��ؼ����� report ����

	return CListView::PreCreateWindow(cs);
}



void CFileView::OnDraw(CDC* /*pDC*/)
{
	CFileDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: �ڴ˴�Ϊ�����������ӻ��ƴ���

	CListCtrl &refCtrl = GetListCtrl();
	refCtrl.InsertItem( 0, "sudami" );
}



void CFileView::OnInitialUpdate()
{
	CRect rect;

	CListView::OnInitialUpdate();

	CFileDoc* pDoc = GetDocument();
	pDoc->m_MTListView = this;

	m_pImage = new CImageList();
	ASSERT( m_pImage != NULL ); 

	m_List->ModifyStyle( LVS_TYPEMASK, LVS_REPORT );
	m_List->SetImageList( m_pImage, LVSIL_SMALL );	
	m_List->SetExtendedStyle( LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES );
	ProcessList->InitSystemImageLists( m_List->m_hWnd );
	m_List->SetExtendedStyle( LVS_EX_FULLROWSELECT | LVS_EX_GRIDLINES );

	GetClientRect(&rect);
	m_List->InsertColumn( 0, "FileName", LVCFMT_LEFT, rect.right/6, -1			);
	m_List->InsertColumn( 1, "FileSize", LVCFMT_RIGHT, rect.right/8, -1			);
	m_List->InsertColumn( 2, "CreateTime", LVCFMT_RIGHT, rect.right/8, -1		);
	m_List->InsertColumn( 3, "FileAttributes", LVCFMT_CENTER, rect.right/8, -1	);
}

// CFileView ���

#ifdef _DEBUG
void CFileView::AssertValid() const
{
	CListView::AssertValid();
}

void CFileView::Dump(CDumpContext& dc) const
{
	CListView::Dump(dc);
}

CFileDoc* CFileView::GetDocument()
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CFileDoc)));
	return (CFileDoc*)m_pDocument;
}
#endif //_DEBUG


/////////////////////////////////////////////////////////////////         --          --     
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//     --     -      -     -- 
//+                                                           +//     --      -   -       -- 
//+                     CFileView ���к���                    +//      --       -        --  
//+                                                           +//       -     sudami     -   
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//        --            --    
/////////////////////////////////////////////////////////////////          --        --  
//                                                                           --    --
//		    																	--


void CFileView::DeleteAllItems()
{
	m_List->DeleteAllItems();
	index = 0 ;
}




void CFileView::AddToListView(PDIRECTORY_INFO_EX fd)
{
	CString  str,temp;

	str.Format( "%s", fd->DirectoryInfo.FileName );
	str = fd->FatherPath + str ;

	m_List->InsertItem(index, fd->DirectoryInfo.FileName);

	/*
	temp.Format("%d-%d-%d",fd->DirectoryInfo.CreationTime.Year,fd->DirectoryInfo.CreationTime.Month,fd->DirectoryInfo.CreationTime.Day);
	m_List->SetItemText(index,2,temp);

	if(fd->DirectoryInfo.AllocationSize.QuadPart>1024*1024*1024)
	{
		temp.Format("%0.2fG",(float)(fd->DirectoryInfo.AllocationSize.QuadPart)/(float)(1024*1024*1024));
	}
	else if(fd->DirectoryInfo.AllocationSize.QuadPart>1024*1024)
	{
		temp.Format("%0.2fM",(float)(fd->DirectoryInfo.AllocationSize.QuadPart)/(float)(1024*1024));
	}
	else if(fd->DirectoryInfo.AllocationSize.QuadPart>1024)
	{
		temp.Format("%0.2fK",(float)(fd->DirectoryInfo.AllocationSize.QuadPart)/(float)(1024));
	}
	else
	{
		temp.Format("%ldB",fd->DirectoryInfo.AllocationSize.QuadPart);
	}
	m_List->SetItemText(index,1,temp);
	temp.Format("%d-%d-%d",fd->DirectoryInfo.LastWriteTime.Year,fd->DirectoryInfo.LastWriteTime.Month,fd->DirectoryInfo.LastWriteTime.Day);
	m_List->SetItemText(index,3,temp);
	temp.Format("%d-%d-%d",fd->DirectoryInfo.LastAccessTime.Year,fd->DirectoryInfo.LastAccessTime.Month,fd->DirectoryInfo.LastAccessTime.Day);
	m_List->SetItemText(index,4,temp);
	switch(fd->DirectoryInfo.FileAttributes)
	{
	case 0x00000001:
		m_List->SetItemText(index,5,"ֻ��");
		break;
	case 0x00000002:
		m_List->SetItemText(index,5,"����");
		break;
	case 0x00000004:
		m_List->SetItemText(index,5,"ϵͳ");
		break;
	case 0x00000020:
		m_List->SetItemText(index,5,"�浵");
		break;
	case 0x00000080:
		m_List->SetItemText(index,5,"����");
		break;
	case 0x00000100:
		m_List->SetItemText(index,5,"��ʱ");
		break;
	case 0x00000800:
		m_List->SetItemText(index,5,"ѹ��");
		break;
	}
	*/

	m_List->SetItem(index, 0, LVIF_TEXT | LVIF_IMAGE,fd->DirectoryInfo.FileName, 
		ProcessList->GetFileIcon(str), 0, 0, 0);
	
	index++ ;
}




LPTSTR CFileView::GetNTS(CString cString)
{
	LPTSTR lpsz = new TCHAR[cString.GetLength() + 1];
	_tcscpy( lpsz, cString );

	return lpsz;
}



void CFileView::SetPath(CString str,HANDLE handle)
{
	path	= str	 ;
	hDevice	= handle ;

	return ;
}


/////////////////////////////////////////////////////////////////         --          --     
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//     --     -      -     -- 
//+                                                           +//     --      -   -       -- 
//+                   CFileView ��Ϣ��������                  +//      --       -        --  
//+                                                           +//       -     sudami     -   
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//        --            --    
/////////////////////////////////////////////////////////////////          --        --  
//                                                                           --    --
//		    																	--


void CFileView::OnStyleChanged(int nStyleType, LPSTYLESTRUCT lpStyleStruct)
{
	return ;
}



void CFileView::OnSize(UINT nType, int cx, int cy) 
{
	CListView::OnSize(nType, cx, cy);

	if( GetListCtrl().GetSafeHwnd() )
	{
		m_List->SetColumnWidth( 0, cx / 5  );
		m_List->SetColumnWidth( 1, cx / 7  );
		m_List->SetColumnWidth( 2, cx / 5  );
		m_List->SetColumnWidth( 3, cx / 8 );
	}
}



void CFileView::OnRclick(NMHDR* pNMHDR, LRESULT* pResult) 
{
	POINT point;
	CMenu menu;

	iSelected = m_List->GetNextItem(-1, LVNI_SELECTED);
	
	::GetCursorPos( &point );
	
	menu.LoadMenu(IDR_MENU_FILE);
	menu.GetSubMenu(0)->TrackPopupMenu(TPM_LEFTALIGN, point.x, point.y, this);

	*pResult = 0;
	return ;
}





void CFileView::OnDiskDelete()
{
	// TODO: �ڴ�����������������
	if(iSelected < 0 || iSelected >= m_List->GetItemCount())
		return;

	char name[255];
	char *ptr = NULL ;
	char *pTmp = NULL ;
	CString str;

	m_List->GetItemText( iSelected,0, name, 255 );

	str.Format("%s",name);
	str=path+str;

	ptr = str.GetBuffer();
	if ( NULL == ptr )
	{
		return ;
	}

	// 	pTmp = strstr( ptr, ":" );
	// 	if ( NULL == pTmp )
	// 	{
	// 		str.ReleaseBuffer();
	// 		return ;
	// 	}
	// 
	// 	pTmp++ ;

	if( 0 == ntfs_fuse_rm( ptr ) )
	{
		m_List->DeleteItem(iSelected);
	}

	str.ReleaseBuffer();
}



void CFileView::OnSysDelete()
{
	if(iSelected < 0 || iSelected >= m_List->GetItemCount())
		return;

	char name[255];
	CString str;

	m_List->GetItemText( iSelected,0, name, 255 );

	str.Format("%s",name);
	str=path+str;

	if(!DeleteFile(str))
	{
		MessageBox("ɾ��ʧ��!");
	}
	else
	{
		m_List->DeleteItem(iSelected);
	}
}