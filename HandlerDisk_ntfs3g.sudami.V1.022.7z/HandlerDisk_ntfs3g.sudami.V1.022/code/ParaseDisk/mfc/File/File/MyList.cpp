/***************************************************************************************
* AUTHOR : sudami [sudami@163.com]
* TIME   : 2009/03/24 [24:3:2009 - 10:51]
* MODULE : d:\Program\R0\Coding\���̲���\code\ParaseDisk\mfc\File\File\MyList.cpp
* 
* Command: 
*   
*   
*
* Description:
*   
*                        
*
***
* Copyright (c) 2008 - 2010 sudami.
* Freely distributable in source or binary for noncommercial purposes.
* TAKE IT EASY,JUST FOR FUN.
*
****************************************************************************************/

#include "stdafx.h"
#include "File.h"
#include "MyList.h"

/////////////////////////////////////////////////////////////////////////////


CMyList::CMyList()
{
}

CMyList::~CMyList()
{
}


BEGIN_MESSAGE_MAP(CMyList, CListCtrl)

	ON_NOTIFY_REFLECT( NM_CUSTOMDRAW, OnNMCustomdraw )

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////

void CMyList::OnNMCustomdraw( NMHDR *pNMHDR, LRESULT *pResult )
{
	*pResult = CDRF_DODEFAULT;
	NMLVCUSTOMDRAW * lplvdr=(NMLVCUSTOMDRAW*)pNMHDR;
	NMCUSTOMDRAW &nmcd = lplvdr->nmcd;

	switch(lplvdr->nmcd.dwDrawStage)
	{
	case CDDS_PREPAINT:		
		*pResult = CDRF_NOTIFYITEMDRAW;
		break;		

	case CDDS_ITEMPREPAINT:
		{
			COLORREF ItemColor;
			if( MapItemColor.Lookup(nmcd.dwItemSpec, ItemColor))
			{
				lplvdr->clrText = ItemColor;
				*pResult = CDRF_DODEFAULT;
			}
		}

		break;
	}
}



void CMyList::SetItemColor( DWORD iItem, COLORREF color )
{
	MapItemColor.SetAt( iItem, color );
	this->RedrawItems( iItem, iItem );

	UpdateWindow();	
}



bool CMyList::InitSystemImageLists( HWND hwndList )
{
	SHFILEINFO sfi;

	HIMAGELIST himlSmall = 
		(HIMAGELIST)::SHGetFileInfo( "C:\\", 0, &sfi, sizeof(SHFILEINFO), SHGFI_SYSICONINDEX | SHGFI_SMALLICON );

	HIMAGELIST himlLarge = 
		(HIMAGELIST)::SHGetFileInfo( "C:\\", 0, &sfi, sizeof(SHFILEINFO), SHGFI_SYSICONINDEX | SHGFI_LARGEICON );

	if( himlSmall && himlLarge ) 
	{
		ListView_SetImageList( hwndList, himlSmall, LVSIL_SMALL );
		ListView_SetImageList( hwndList, himlLarge, LVSIL_NORMAL );

		return TRUE ;
	}

	return FALSE ;
}



int CMyList::GetFileIcon( LPCTSTR lpFileName )
{
	SHFILEINFO sfi ;

	SHGetFileInfo( 
		lpFileName, 
		0,
		&sfi,
		sizeof(sfi),
		SHGFI_ICON | SHGFI_SMALLICON | SHGFI_LARGEICON
		);
	
	return sfi.iIcon;
}

