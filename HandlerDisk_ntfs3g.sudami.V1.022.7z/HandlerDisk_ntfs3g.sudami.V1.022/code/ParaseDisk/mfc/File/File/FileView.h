#pragma once

#include "FileDoc.h"
#include "MyList.h"

#include <afxcview.h>

//////////////////////////////////////////////////////////////////////////


class CFileView : public CListView
{
protected:
	CFileView();
	DECLARE_DYNCREATE(CFileView)

// ����
public:
	CFileDoc* GetDocument() ;
	CMyList       *m_List	;
	int           iSelected	;

// ��д
	virtual void OnDraw(CDC* pDC); 
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void OnInitialUpdate();

// ʵ��
public:
	virtual ~CFileView();

	ULONG	index	; // ��ǰ�б���ʾ���ļ�����
	HANDLE	hDevice	; 
	CString path	; // ��ǰλ�õ��ļ�·��
	
	void SetPath( CString str, HANDLE handle );
	void AddToListView( PDIRECTORY_INFO_EX fd );
	void DeleteAllItems();
	LPTSTR GetNTS( CString cString );


#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	CImageList  *m_pImage ;

// ���ɵ���Ϣӳ�亯��
protected:

	afx_msg void OnStyleChanged(int nStyleType, LPSTYLESTRUCT lpStyleStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnRclick( NMHDR* pNMHDR, LRESULT* pResult );
	afx_msg void OnDiskDelete();
	afx_msg void OnSysDelete();

	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // FileView.cpp �еĵ��԰汾
inline CFileDoc* CFileView::GetDocument()
   { return reinterpret_cast<CFileDoc*>(m_pDocument); }
#endif

