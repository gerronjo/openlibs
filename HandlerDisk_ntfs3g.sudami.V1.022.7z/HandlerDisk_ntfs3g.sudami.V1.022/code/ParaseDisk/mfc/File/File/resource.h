//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by File.rc
//
#define IDR_MENU_FILE                   4
#define ICO_CDDRV                       5
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDR_MAINFRAME                   128
#define IDR_FileTYPE                    129
#define ICO_MYCOMP                      132
#define ICO_OPENFLD                     133
#define IDI_ICON2                       134
#define IDI_ICON3                       135
#define IDI_ICON1                       136
#define IDI_ICON4                       136
#define IDM_DELETE_FILE                 32771
#define IDM_DISK_DELETE                 32772
#define IDR_SYS_DELETE                  32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
