#pragma once

#include "stdafx.h"

#include <stdio.h> // snprintf()
#include <stdlib.h>
#include <string.h>
#include <afxwin.h>
#include <errno.h>
#include <fcntl.h>
#include <stdlib.h>
#include <locale.h>
#include <signal.h>
#include <limits.h>
#include <sys/stat.h>

#include "attrib.h"
#include "inode.h"
#include "volume.h"
#include "dir.h"
#include "unistr.h"
#include "layout.h"
#include "index.h"
#include "utils.h"
#include "version.h"
#include "ntfstime.h"
#include "misc.h"
#include "types.h"
#include "ReadWrite/ReadWriteDisk.h"

#include "LeftView.h"


//////////////////////////////////////////////////////////////////////////

VOID 
GetPartitionNumber (
	IN char* szFilePath
	);

int 
ntfs_fuse_open(
	IN const char *org_path
	) ;

int 
ntfs_fuse_read(
	IN const char *org_path, 
	OUT char *buf,
	IN size_t size,
	IN off_t offset
	) ;

int 
ntfs_fuse_write(
	IN const char *org_path, 
	IN const char *buf, 
	IN size_t size,
	IN off_t offset
	) ;

int 
ntfs_fuse_create(
	IN const char *org_path, 
	IN dev_t type, 
	IN dev_t dev,
	IN const char *target
	) ;

int 
ntfs_fuse_create_stream(
	const char *path,
	ntfschar *stream_name,
	const int stream_name_len
	) ;

int 
ntfs_fuse_mknod(
	IN const char *org_path, 
	int mode, 
	dev_t dev
	) ;

int ntfs_fuse_symlink(const char *to, const char *from);

int ntfs_fuse_link(const char *old_path, const char *new_path);

VOID
ntfs_fuse_Enum(
	IN const char *org_path
	) ;

int 
ntfs_enumerate_dir_ex(
	IN const char *path,
	CTreeCtrl& treeCtrl
	) ;

int 
ntfs_fuse_rm(
	IN const char *org_path
	) ;

int 
ntfs_fuse_rm_stream(
	IN const char *path, 
	IN ntfschar *stream_name,
	IN const int stream_name_len
	) ;

int 
ntfs_fuse_unlink(
	IN const char *org_path
	) ;

int ntfs_fuse_rename(const char *old_path, const char *new_path);

int 
ntfs_fuse_mkdir(
	IN const char *path
	) ;

int 
ntfs_fuse_rmdir(
	IN const char *path
	) ;


int ntfs_fuse_init(void);
void ntfs_fuse_destroy(void);

ntfs_volume *
ntfs_open(
	IN const char *device,
	IN int blkdev
	) ;

//////////////////////////////////////////////////////////////////////////
