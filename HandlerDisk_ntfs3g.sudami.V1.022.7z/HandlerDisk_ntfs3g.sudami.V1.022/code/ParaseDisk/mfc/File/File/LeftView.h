#pragma once

#include <afxcview.h>

//////////////////////////////////////////////////////////////////////////

#define ILI_CDDRV     0
#define ILI_CLSDFLD   1
#define ILI_DRIVE     2 
#define ILI_FLOPPYDRV 3 
#define ILI_MYCOMP    4
#define ILI_OPENFLD   5 
#define ILI_TEXTFILE  6 

class CDriveExplorerDoc;


//////////////////////////////////////////////////////////////////////////



//////////////////////////////////////////////////////////////////////////


class CLeftView : public CTreeView
{
protected: 
	
	DECLARE_DYNCREATE(CLeftView)

public:
	CLeftView();

	CDriveExplorerDoc* GetDocument();
	CImageList* m_pImageList;
	HANDLE  hDevice;
	CString m_LocalPath;

public:
	BOOL HasSubdirectory(CString &strPathName);
	BOOL IsDriveNode(HTREEITEM hItem);
	void SetButtonState(HTREEITEM hItem, CString &strPathName, CTreeCtrl& treeCtrl);
	UINT AddDirectoryNodes(HTREEITEM hItem, CString &strPathName);
	BOOL IsMediaValid(CString &strPathName);
	HTREEITEM GetDriveNode(HTREEITEM hItem);
	UINT DeleteChildren(HTREEITEM hItem);
	BOOL IsPathValid(CString &strPathName);
	CString GetPathFromItem(HTREEITEM hItem);
	void AddDummyNode(HTREEITEM hItem, CTreeCtrl& treeCtrl);
	void InitTreeView(HTREEITEM hParent);
	BOOL AddDrives(CString strDrive, HTREEITEM hParent);

	void Insert_tree_list_node( LPCTSTR szName, int a, int b, BOOL bIsDiretory, CTreeCtrl& treeCtrl );
	
public:
	virtual void OnDraw(CDC* pDC); 
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void OnInitialUpdate(); 

public:
	virtual ~CLeftView();

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	
	afx_msg void OnDestroy();
	afx_msg void OnItemexpanding(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSelchanging(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnRButtonDblClk(UINT nFlags, CPoint point);
	
	DECLARE_MESSAGE_MAP()
};


#ifndef _DEBUG  // debug version in LeftView.cpp
inline CDriveExplorerDoc* CLeftView::GetDocument()
{ return (CDriveExplorerDoc*)m_pDocument; }
#endif
