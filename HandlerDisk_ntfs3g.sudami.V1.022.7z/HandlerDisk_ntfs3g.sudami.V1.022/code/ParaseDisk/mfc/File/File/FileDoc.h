#pragma once

//////////////////////////////////////////////////////////////////////////


class CFileView ; // ��doc������ view��


//////////////////////////////////////////////////////////////////////////

class CFileDoc : public CDocument
{
protected:
	CFileDoc();
	DECLARE_DYNCREATE(CFileDoc)

public:
	CFileView* m_MTListView; // ������һ��

	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

	virtual ~CFileDoc();

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	DECLARE_MESSAGE_MAP()
};


