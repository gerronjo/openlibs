/*
 * compat.h - Tweaks for Windows compatibility.
 */

#ifndef _NTFS_COMPAT_H
#define _NTFS_COMPAT_H

#ifdef __cplusplus 
extern "C" { 
#endif


extern int ffs(int i);

#ifdef __cplusplus 
} 
#endif

//////////////////////////////////////////////////////////////////////////


#endif /* defined _NTFS_COMPAT_H */

