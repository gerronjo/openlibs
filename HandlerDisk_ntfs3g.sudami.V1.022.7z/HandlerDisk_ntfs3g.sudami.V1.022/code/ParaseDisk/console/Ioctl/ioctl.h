#pragma once

#include <winioctl.h>


//
// The device driver IOCTLs
//

#define IOCTL_BASE	0x800
#define MY_CTL_CODE(i) \
CTL_CODE(FILE_DEVICE_UNKNOWN, IOCTL_BASE+i, METHOD_BUFFERED, FILE_ANY_ACCESS)


#define IOCTL_INIT_SECTORS		MY_CTL_CODE(0)
#define IOCTL_READ_SECTORS		MY_CTL_CODE(1)
#define IOCTL_WRITE_SECTORS		MY_CTL_CODE(2)
