/*
 * logging.h - Centralised logging. Originated from the Linux-NTFS project.
 */

#ifndef _LOGGING_H_
#define _LOGGING_H_

#include <stdarg.h>
#include "types.h"

#define ntfs_log_debug /*printf*/
#define ntfs_log_trace /*printf*/
#define ntfs_log_error /*printf*/
#define ntfs_log_perror /*printf*/

#endif /* _LOGGING_H_ */

