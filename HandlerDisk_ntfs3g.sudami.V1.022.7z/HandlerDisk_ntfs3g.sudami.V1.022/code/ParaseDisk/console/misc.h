#ifndef _NTFS_MISC_H_
#define _NTFS_MISC_H_

extern void *ntfs_calloc(size_t size);
extern void *ntfs_malloc(size_t size);

#endif /* _NTFS_MISC_H_ */

