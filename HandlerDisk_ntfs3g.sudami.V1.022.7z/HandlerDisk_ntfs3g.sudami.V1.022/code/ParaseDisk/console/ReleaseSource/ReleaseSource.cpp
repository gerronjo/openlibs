#pragma once

#include "../Stdafx.h"
#include "ReleaseSource.h"


//////////////////////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////////////////////////////
//---------------------------------------------------------------------------------
//  ������:    IsFileExist
//
//  ����:      LPCTSTR   lpcsFileName
//             �ļ�����·��
//  
//  ����ֵ:    TURE / FALSE          
//          
//  ��������:  �ж�ָ���ļ��Ƿ����
//--------------------------------------------------------------------------------- 
BOOL IsFileExist (LPCTSTR lpcsFileName)   
{   
#ifdef  _UNICODE   
	if((_waccess(lpcsFileName, 0)) != -1 )   
#else   
	if((_access(lpcsFileName, 0 )) != -1 )   
#endif   
		return   TRUE;   
	else	
		return   FALSE;   
}   



//////////////////////////////////////////////////////////////////////////////////
//--------------------------------------------------------------------------------
//  ������:    ReleaseSYS
//
//  ����:      LPCTSTR szProcName --> ָ���ͷ�SYS��λ��
//  
//  ����ֵ:    TRUE / FALSE        
//          
//  ��������:  �ͷ�SYS��Դ,������sudami.SYS
//--------------------------------------------------------------------------------   
BOOL ReleaseSYS (LPCTSTR szSYSName, int nSYSID )
{
	DWORD     dwWritten = 0; 
	HMODULE   hInstance   =   ::GetModuleHandle(NULL);   

	//��λ�Զ�����Դ
	HRSRC hRsrc = FindResource(hInstance, MAKEINTRESOURCE(nSYSID), TEXT("SYS"));
	if (NULL == hRsrc)
	{
		return FALSE;
	}

	//��ȡ��Դ�Ĵ�С
	DWORD dwSYSSize = SizeofResource(NULL, hRsrc); 
	if (0 == dwSYSSize)
	{
		return FALSE;
	}

	//������Դ
	HGLOBAL hGlobal = LoadResource(NULL, hRsrc); 
	if (NULL == hGlobal)
	{
		return FALSE;
	}

	//������Դ
	LPVOID pBuffer = LockResource(hGlobal); 
	if (NULL == pBuffer)
	{
		return FALSE;
	}


	char* szSYSPath = (LPTSTR)(LPCTSTR)szSYSName;
	if (IsFileExist(szSYSPath))
	{
		/*******************************************************
		*                                                      *
		*           ���sudami.SYS�Ѿ����ڣ�ɾ��֮             *
		*                                                      *
		********************************************************/

		//AfxMessageBox (TEXT("sudami.SYS�Ѿ�����"));
		::DeleteFile (szSYSPath);

		// ��sys�ͷŵ� C:\WINDOWS\system32\drivers ��
		HANDLE hFileForSYS = ::CreateFile(     
			szSYSName,   
			GENERIC_WRITE,   
			0,   
			NULL,   
			CREATE_ALWAYS,   
			//			FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM,  
			FILE_ATTRIBUTE_NORMAL,
			NULL   
			);   

		if (hFileForSYS == INVALID_HANDLE_VALUE)   
		{   
			return FALSE;   
		}   

		::WriteFile (hFileForSYS, pBuffer, dwSYSSize, &dwWritten, NULL);   
		::CloseHandle (hFileForSYS);

		return TRUE;
	}
	else            /* sudami.sys������,����֮ */
	{ 
		// ��sys�ͷŵ� C:\WINDOWS\system32\drivers ��
		HANDLE hFileForSYS = ::CreateFile(     
			szSYSName,   
			GENERIC_WRITE,   
			0,   
			NULL,   
			CREATE_ALWAYS,   
			FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM,  
			NULL   
			);   

		if (hFileForSYS == INVALID_HANDLE_VALUE)   
		{   
			return FALSE;   
		}   

		::WriteFile (hFileForSYS, pBuffer, dwSYSSize, &dwWritten, NULL);   
		::CloseHandle (hFileForSYS);   
		return TRUE;
	}
}
