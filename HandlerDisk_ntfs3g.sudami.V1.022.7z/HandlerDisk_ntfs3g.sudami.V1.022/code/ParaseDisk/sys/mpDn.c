/***************************************************************************************
* AUTHOR : sudami [sudami@163.com]
* TIME   : 2009/03/16 [16:3:2009 - 15:42]
* MODULE : D:\Program\R0\Coding\SCSI\mpDn.c
*   
* Description:
*   
*   �����ȡ/д�� Ӧ�ò����ָ��������                      
*
***
* Copyright (c) 2008 - 2010 sudami.
* Freely distributable in source or binary for noncommercial purposes.
* TAKE IT EASY,JUST FOR FUN.
*
****************************************************************************************/

#include "struct.h"
#include "mpDn.h"
#include "header.h"
#include "ioctl.h"
#include "CreateTmpThread.h"

#include <ntddk.h>
#include <srb.h>
#include <SCSI.h>
#include <stdio.h>

//////////////////////////////////////////////////////////////////////////

extern POBJECT_TYPE* IoDriverObjectType;
extern THREAD_INFO g_tmpThread_info ;


ULONG g_sectors_per_cluster				= 0		; 
PETHREAD g_system_ethread				= NULL	;
PDEVICE_OBJECT g_atapi_dev				= NULL	;
PLARGE_INTEGER g_partitionA_sector_pos[10] = { NULL } ;
PVOID g_pTmppool						= NULL	; // driverinit()�з���һ����ڴ�,��ʱ�洢Read������Ϣ


//////////////////////////////////////////////////////////////////////////

NTSTATUS
IrpCompletionRoutine (
	IN PDEVICE_OBJECT DeviceObject,
	IN PIRP Irp,
	IN PVOID Context
	)
{
	PMDL mdl ;
	Irp->UserIosb->Status		= Irp->IoStatus.Status		;
	Irp->UserIosb->Information	= Irp->IoStatus.Information	;

	if( !Context )
	{
		mdl = Irp->MdlAddress;
		if( mdl )
		{
		//	DbgPrint("read size: %d..", Irp->IoStatus.Information);
			MmUnlockPages( mdl );
			IoFreeMdl( mdl );
		}
	}

	KeSetEvent( Irp->UserEvent, IO_NO_INCREMENT, 0 );
	IoFreeIrp( Irp );
	
	return STATUS_MORE_PROCESSING_REQUIRED;
}



NTSTATUS 
IrpCompletionRoutine_0 (
	IN PDEVICE_OBJECT  DeviceObject,
	IN PIRP  Irp,
	IN PVOID  Context
	)
{
	PMDL mdl ;
	Irp->UserIosb->Status		= Irp->IoStatus.Status		;
	Irp->UserIosb->Information	= Irp->IoStatus.Information	;

	if ( !Context )
	{
		mdl = Irp->MdlAddress ;
		if ( mdl )
		{
		//	DbgPrint("read size: %d..", Irp->IoStatus.Information);
			MmUnlockPages(mdl);
			IoFreeMdl(mdl);
		}
	}

	KeSetEvent(Irp->UserEvent, IO_NO_INCREMENT, 0);
	IoFreeIrp(Irp);

	return STATUS_MORE_PROCESSING_REQUIRED ;
}



ULONG 
GetModuleBase (
	IN char* name
	)
{
	
    ULONG                       n,i ;
    PSYSTEM_MODULE_INFORMATION  module;
    PVOID                       pbuftmp;
	char modulename[255];
	
    ZwQuerySystemInformation( 11, &n, 0, &n );
    pbuftmp = ExAllocatePool( NonPagedPool, n );
    ZwQuerySystemInformation( 11, pbuftmp, n, NULL );
	
	module = (PSYSTEM_MODULE_INFORMATION)((PULONG )pbuftmp + 1 );
	n      = *((PULONG)pbuftmp );
    for ( i = 0; i < n; i++ )
    {
		strcpy(modulename,module[i].ImageName + module[i].ModuleNameOffset);
		if(!_strnicmp(modulename,name,strlen(name))){
			ExFreePool(pbuftmp);
			return (ULONG)module[i].Base;
		}
    }
	
	ExFreePool(pbuftmp);
	return 0;
}



NTSTATUS 
MyIoCallDriver (
	PDEVICE_OBJECT DeviceObject,
	PIRP Irp
	)
{
	PIO_STACK_LOCATION stack;
	--Irp->CurrentLocation;
	stack = IoGetNextIrpStackLocation( Irp );
	Irp->Tail.Overlay.CurrentStackLocation= stack;//�ƶ���ջ
	stack->DeviceObject=DeviceObject;

	return (DeviceObject->DriverObject->MajorFunction[(ULONG)stack->MajorFunction])(DeviceObject, Irp);
}




PDEVICE_OBJECT 
GetLastDiskDeviceObject (
	PDRIVER_OBJECT drv_object
	)
{
	PDEVICE_OBJECT result = NULL ;
	PDEVICE_OBJECT finddev;
	finddev = drv_object->DeviceObject;

	while (finddev)
	{
		if (finddev->DeviceType==FILE_DEVICE_DISK)
			result = finddev;

		finddev=finddev->NextDevice;
	}

	return result;
}



PDEVICE_OBJECT 
GetAtaDr0DevObject (
	)
{
	UNICODE_STRING diskstr	;
	PDRIVER_OBJECT diskdrv	;
	PDEVICE_OBJECT dr0dev	;

    RtlInitUnicodeString(&diskstr, L"\\Driver\\Disk");
	if( ObReferenceObjectByName( &diskstr, 64, 0, 0, *IoDriverObjectType, 0, 0, &diskdrv ) < 0 )
		return NULL;
	
	dr0dev = GetLastDiskDeviceObject( diskdrv );
	
	ObfDereferenceObject( diskdrv );

	return dr0dev;
}



PDEVICE_OBJECT 
GetFileObjectDevice (
	PFILE_OBJECT Object
	)
{
	
	PDEVICE_OBJECT result = NULL;
	PVPB vpb ;
	vpb = Object->Vpb ;
	result = vpb->DeviceObject ;

	if( !vpb || !result )
	{
		if( !Object->DeviceObject->Vpb || !Object->DeviceObject->Vpb->DeviceObject )
			result = Object->DeviceObject ;
	}

	return result;
}


//////////////////////////////////////////////////////////////////////////

int g_nNumber = 0 ;

VOID
Parase_partion_depth (
	PDEVICE_OBJECT dev,
	PMBR_SECTOR mbrsec,
	ULONG currentSectors,
	PVOID pTmp
	)
/*++

Author: sudami [sudami@163.com]
Time  : 2009/03/23 [23:3:2009 - 16:16]

Routine Description:
    
    
Arguments:

     - 
    
--*/
{
	int MainPartNumber	;
	ULONG startlba			;
	UCHAR type				;
	PPARTITION_ENTRY partition0 = NULL ;
	PBBR_SECTOR bootsec			= NULL ;
	PLARGE_INTEGER result		= NULL ;
	PVOID buffer				= pTmp ;

	for ( MainPartNumber = 0; MainPartNumber < 4; MainPartNumber++ )
	{
		partition0	= &mbrsec->Partition[MainPartNumber]	;
		startlba	= partition0->StartLBA					;
		type		= partition0->PartitionType				;
		
		// �����ܹ���4��������, ��Ϊ0��ʾ��������������,����֮.
		if ( 0 == startlba || ( 0 != partition0->active && 0x80 != partition0->active ) ) {
			break ;
		}

		startlba += currentSectors ;

		//
		// У�鵱ǰ����������:
		//   07HΪNTFS����
		//   0BHΪFAT32����
		//   05HΪEXTEND��չ����(�÷�������ʼ����Ϊ "ǰ��ĵ�һ��EXTENDX������ʼ����" + "�÷��������ƫ��")
		//   0FHΪEXTENDX��չ����(�÷�������ʼ����Ϊ "�÷��������ƫ��" ���� "ǰ��ĵ�һ��EXTENDX������ʼ����" + "�÷��������ƫ��")
		//
		
		memset( buffer, 0, 512 );

		if ( 0x05 == type ) // ��EXTEND��չ����
		{
			startlba = currentSectors + mbrsec->Partition[MainPartNumber-1].StartLBA
				+ mbrsec->Partition[MainPartNumber-1].TotalSector ;

			AtapiReadWriteDisk( dev, IRP_MJ_READ, buffer, startlba, 1 );
		//	mbrsec = (PMBR_SECTOR) buffer ;
			memcpy( (PVOID)mbrsec, buffer, 512 );
			Parase_partion_depth( dev, mbrsec, startlba, buffer );
			
			continue ;
		} 

		else if ( 0x07 == type ) // ��NTFS���� ------- OK -------
		{
			AtapiReadWriteDisk( dev, IRP_MJ_READ, buffer, startlba, 1 );

			// �����ڴ�
			result = Kmalloc( sizeof(LARGE_INTEGER) );
			result->QuadPart = startlba ;
		
			// ��ȡ��������BPB�ṹ,��ñ�������������
			bootsec = (PBBR_SECTOR) buffer ; 
			g_sectors_per_cluster = bootsec->SectorsPerCluster ;
			
			result->QuadPart += bootsec->ReservedSectors ;
		}

		else if ( 0x0F == type ) // ��EXTENDX��չ����
		{
			AtapiReadWriteDisk( dev, IRP_MJ_READ, buffer, startlba, 1 );

		//	mbrsec = (PMBR_SECTOR) buffer ;
			memcpy( (PVOID)mbrsec, buffer, 512 );
			Parase_partion_depth( dev, mbrsec, startlba, buffer );
			
			continue ;
		}
		
		// ����fat32��ʽ,��Ҫ����Դ�
		else if( type == PARTITION_TYPE_FAT32 || type == PARTITION_TYPE_FAT32_LBA ) 
		{
			AtapiReadWriteDisk( dev, IRP_MJ_READ, buffer, startlba, 1 );
			result->QuadPart += bootsec->NumberOfFATs * bootsec->SectorsPerFAT32 ;
		} else {
			break ;
		}

		// ��������������������ȫ�ֱ���
		g_partitionA_sector_pos[g_nNumber] = result ;
		g_nNumber++ ;

		dprintf( "����%d�ڴ����ϵ���ʼ����: 0x%08lx \n", g_nNumber, result->QuadPart );

		if ( g_nNumber > 10 ) { // Խ����. �˳�
			break ;
		}
	}

	return ;
}


VOID 
Get_all_partition_sector (
	) 
/*++

Author: sudami [sudami@163.com]
Time  : 2009/03/23 [23:3:2009 - 15:13]

Routine Description:
  �õ��������з���������λ��(������������̵�������)  
    
--*/
{
	PVOID	buffer = NULL, pTmp = NULL ;
	PMBR_SECTOR		mbrsec	= NULL ;
	PDEVICE_OBJECT	dev		= NULL ;

	
	dev = GetAtaDr0DevObject() ;
	if( NULL == dev) { return ; }

	pTmp = Kmalloc( 0x1000 );

	// ��MBR,�õ���������Ϣ
	buffer = Kmalloc( 512 );
	memset( buffer, 0, 512 );
	AtapiReadWriteDisk( dev, IRP_MJ_READ, buffer, 0, 1 ) ;
	
	mbrsec = (PMBR_SECTOR) buffer ;
	Parase_partion_depth( dev, mbrsec, 0, pTmp );

	Kfree( buffer );
	Kfree( pTmp );
	
	return ;
}



// �õ���һ�������ļ����ݵ���ʼλ��
PLARGE_INTEGER 
Get_partition_sector (
	) 
{
	PVOID buffer;
	ULONG type,startlba;
	int i;
	PLARGE_INTEGER result;
	PDEVICE_OBJECT dev;
	PMBR_SECTOR mbrsec;
	PPARTITION_ENTRY partition0;
	PBBR_SECTOR bootsec;

	result = ExAllocatePool( 0, sizeof(LARGE_INTEGER) );
	dev = GetAtaDr0DevObject() ;
	if(dev)
	{
        buffer=ExAllocatePool(0,512);
        memset(buffer,0,512);
        AtapiReadWriteDisk( dev, IRP_MJ_READ, buffer, 0, 1 ) ;
		
        mbrsec=(PMBR_SECTOR)buffer;
        partition0=&mbrsec->Partition[0];
        startlba=partition0[0].StartLBA;
        type=partition0[0].PartitionType;
        result->QuadPart=startlba;
        memset(buffer,0,512);

        if(AtapiReadWriteDisk(dev, IRP_MJ_READ, buffer, startlba, 1)>0)
		{
			bootsec = (PBBR_SECTOR) buffer ;
			g_sectors_per_cluster = bootsec->SectorsPerCluster;
        }
        result->QuadPart+=bootsec->ReservedSectors;
        if(type==PARTITION_TYPE_FAT32||type==PARTITION_TYPE_FAT32_LBA)
			result->QuadPart+=bootsec->NumberOfFATs*bootsec->SectorsPerFAT32;
		
	} else {
		result->QuadPart = 0 ;
	}
	
	return result ;
}



NTSTATUS 
OpenFile (
	PHANDLE FileHandle,
	PWCHAR filename
	)
{
	NTSTATUS status; 
	ULONG v3; 
	int v5; 
	UNICODE_STRING DestinationString; 
	OBJECT_ATTRIBUTES ObjectAttributes; 
	struct _IO_STATUS_BLOCK IoStatusBlock; 
	
	RtlInitUnicodeString(&DestinationString, filename); // L"\\SystemRoot\\System32\\userinit.exe"
	ObjectAttributes.ObjectName = &DestinationString;
	ObjectAttributes.Length = 24;
	ObjectAttributes.RootDirectory = 0;
	ObjectAttributes.Attributes =OBJ_KERNEL_HANDLE | OBJ_CASE_INSENSITIVE;// 576;
	ObjectAttributes.SecurityDescriptor = 0;
	ObjectAttributes.SecurityQualityOfService = 0;
	status = IoCreateFile(FileHandle, GENERIC_READ , &ObjectAttributes, &IoStatusBlock, 0, FILE_ATTRIBUTE_NORMAL, FILE_SHARE_READ, FILE_OPEN , 0x50u, 0, 0, 0, 0, 0);
	if ( status != STATUS_SUCCESS)
		DbgPrint("Open File failed...%08x..", status );

	return status;
}



PLARGE_INTEGER 
Get_file_size(
	PWCHAR filename
	)
{
	PLARGE_INTEGER filesize;
	HANDLE hfile;
	IO_STATUS_BLOCK IoStatusBlock;
	filesize=ExAllocatePool(0,sizeof(LARGE_INTEGER));
	OpenFile(&hfile,filename);
	ZwQueryInformationFile(hfile, &IoStatusBlock, filesize, 24, FileStandardInformation);

	return filesize;
}




LARGE_INTEGER 
Get_file_SectorPoint(
	IN PWCHAR filename
	)
/*++

Author: sudami [sudami@163.com]
Time  : 2009/03/16 [16:3:2009 - 17:30]

Routine Description:
  �õ��ļ���������λ�ã������realdiskpos  
    
Arguments:
  filename - �ļ�ȫ·��. eg. L"\\??\\c:\\sudami.txt"

Return Value:
  ���ظ��ļ���LCN
    
--*/
{	
	LARGE_INTEGER realdiskpos = { 0 } ;
	NTSTATUS status,newstatus;
	HANDLE filehandle;
	PVOID testingpool;
	IO_STATUS_BLOCK iosb;
	LARGE_INTEGER ByteOffset;
	PFILE_OBJECT Object; 
	PDEVICE_OBJECT dev;
	PIRP irp;
	KEVENT Event;
	IO_STATUS_BLOCK iosb2;
    PIO_STACK_LOCATION nextio;
	STARTING_VCN_INPUT_BUFFER StartVcn;
	unsigned char abBuffer[1024];
    PRETRIEVAL_POINTERS_BUFFER pVcnPairs;
	UNICODE_STRING uniFilePath ;
	ANSI_STRING		filefullname_a; 
	char *szttttt = NULL, *ptr = NULL ;
	int drive_id = 0 ;

	realdiskpos.QuadPart=0;
	StartVcn.StartingVcn.QuadPart=0;
	
    memset( abBuffer, 0, 1024 );
    pVcnPairs = (PRETRIEVAL_POINTERS_BUFFER) abBuffer;

	//
	// ȷ����ǰ����
	//

	RtlInitUnicodeString(&uniFilePath, filename );
	RtlUnicodeStringToAnsiString( &filefullname_a, &uniFilePath, TRUE ) ;
	ptr = strstr( filefullname_a.Buffer, ":" );
	if ( NULL == ptr )
	{
		dprintf( "error! Get_file_SectorPoint() | ����ȷ����ǰ���� \n" );
		return realdiskpos ;
	}
	
	*ptr = '\0' ;
	szttttt = (char*)(--ptr) ;

	drive_id = toupper( *(char*)szttttt ) - 'C';

	// free memory
	if( filefullname_a.Buffer )   ExFreePool( filefullname_a.Buffer );

	//
	// ���ļ�,��ȡ��Ϣ
	//
	
	if( OpenFile(&filehandle,filename) != STATUS_SUCCESS )
		return realdiskpos;
	
	testingpool = ExAllocatePool( 0, 512 );
	ByteOffset.QuadPart= 0 ;
	if( ZwReadFile(filehandle,0,0,0,&iosb,testingpool,512,&ByteOffset,0) != STATUS_SUCCESS )
	{
		DbgPrint("ZwReadFile error");
		goto end;
	}

	if( ObReferenceObjectByHandle(filehandle,0,(POBJECT_TYPE)*IoFileObjectType,0,&Object,0) < 0 )
	{
		DbgPrint("ObReferenceObjectByHandle error");
		goto end;
	}

	dev = GetFileObjectDevice( Object );
	if( !dev )
	{
        DbgPrint("Get Device Object error");
        goto end2;
	}

	
	irp = IoAllocateIrp( dev->StackSize, 0 );
	if( irp == NULL )
		goto end2;

	/*++

  ����Ҫ�޸�ϵͳ��װ��DDK ��typedef struct _IO_STACK_LOCATION { ����:

		//
		// strct -- FileSystemControl
		//
		
		  struct {
		  ULONG OutputBufferLength;
		  ULONG InputBufferLength;
		  ULONG FsControlCode;
		  PVOID Type3InputBuffer;
		} FileSystemControl ;
	
	--*/
	
	KeInitializeEvent(&Event, SynchronizationEvent, 0);
	irp->AssociatedIrp.SystemBuffer=&StartVcn;
	irp->UserBuffer=pVcnPairs;
	irp->UserEvent=&Event;
	irp->MdlAddress=0;
	irp->UserIosb=&iosb2;
	irp->RequestorMode=KernelMode;
	irp->Tail.Overlay.Thread=PsGetCurrentThread();
	irp->Tail.Overlay.OriginalFileObject=Object;
	irp->Flags = 0;
	nextio = IoGetNextIrpStackLocation(irp);
	nextio->MajorFunction=IRP_MJ_FILE_SYSTEM_CONTROL;
	nextio->DeviceObject=dev;
	nextio->FileObject=Object;
	nextio->Parameters.FileSystemControl.InputBufferLength= sizeof(STARTING_VCN_INPUT_BUFFER);
	nextio->Parameters.FileSystemControl.FsControlCode=FSCTL_GET_RETRIEVAL_POINTERS;
	nextio->Parameters.FileSystemControl.Type3InputBuffer=&StartVcn;
	nextio->Parameters.FileSystemControl.OutputBufferLength=1024;
	nextio->CompletionRoutine=IrpCompletionRoutine;
	nextio->Context=0;
	nextio->Control=SL_INVOKE_ON_CANCEL|SL_INVOKE_ON_SUCCESS|SL_INVOKE_ON_ERROR;
	
    MyIoCallDriver(dev,irp);
	
	KeWaitForSingleObject(&Event, 0,0,0, NULL);
	newstatus = iosb2.Status;
	
	if( newstatus<0 ) {
		goto end2;
	}
	
// 	if ( NULL == g_partitionA_sector_pos ) {
// 		g_partitionA_sector_pos = Get_partition_sector() ;
// 	}
	
	realdiskpos.QuadPart = 
		g_partitionA_sector_pos[drive_id]->QuadPart + g_sectors_per_cluster * pVcnPairs->Extents[0].Lcn.QuadPart;
	
	if(g_partitionA_sector_pos[drive_id])
	{
		dprintf (
			" ------------------------------------------------- \n"
			"| ���ļ�����ʼ Lcn = 0x%I64x \n"
			"| ���ļ��ڴ�����Ҫ��������ʼ������: 0x%08lx \n"
			"| ÿ���ص�������: %d \n"
			"| �÷����ڴ����ϵ�������(Offset): 0x%08lx \n"
			" ------------------------------------------------- \n",
			pVcnPairs->Extents[0].Lcn.QuadPart,
			realdiskpos.LowPart,
			g_sectors_per_cluster, 
			g_partitionA_sector_pos[drive_id]->QuadPart 
			);
	}
	
	return realdiskpos ;
	
end2:
	if( irp != NULL )
        IoFreeIrp( irp );
	ObDereferenceObject( Object );
end:
	ZwClose( filehandle );
	if( testingpool )
		ExFreePool( testingpool );

	return realdiskpos ;
}



/////////////////////////////////////////////////////////////////         --          --     
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//     --     -      -     -- 
//+                                                           +//     --      -   -       -- 
//+				      DriverEntry,Unload...                   +//      --       -        --  
//+                                                           +//       -     sudami     -   
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//        --            --    
/////////////////////////////////////////////////////////////////          --        --  
//                                                                           --    --
//		    																	--


NTSTATUS 
DriverEntry(
	PDRIVER_OBJECT pDriverObj, 
	PUNICODE_STRING pRegistryString
	)
{
	NTSTATUS status = STATUS_SUCCESS;
	UNICODE_STRING ustrLinkName;
	UNICODE_STRING ustrDevName;    
	PDEVICE_OBJECT pDevObj;
	

	dprintf("[sudami] DriverEntry\n");
	
	pDriverObj->MajorFunction[IRP_MJ_CREATE] = DispatchCreate;
	pDriverObj->MajorFunction[IRP_MJ_CLOSE] = DispatchClose;
	pDriverObj->MajorFunction[IRP_MJ_DEVICE_CONTROL] = DispatchIoctl;
	pDriverObj->DriverUnload = DriverUnload;

	RtlInitUnicodeString(&ustrDevName, DEVICE_NAME);
	status = IoCreateDevice(pDriverObj, 
				0,
				&ustrDevName, 
				FILE_DEVICE_UNKNOWN,
				0,
				FALSE,
				&pDevObj);

	if(!NT_SUCCESS(status))	{
		dprintf("[sudami] IoCreateDevice = 0x%x\n", status);
		return status;
	}

	RtlInitUnicodeString(&ustrLinkName, LINK_NAME);
	status = IoCreateSymbolicLink(&ustrLinkName, &ustrDevName);  
	if(!NT_SUCCESS(status)) {
		dprintf("[sudami] IoCreateSymbolicLink = 0x%x\n", status);
		IoDeleteDevice(pDevObj);  
		return status;
	}

	//
	// ����ִ�д���
	//

	DriverInit() ;
	Scsi_read_file_by_name( L"\\??\\D:\\sudami.txt" );

	return STATUS_SUCCESS;
}



VOID 
DriverUnload(
	PDRIVER_OBJECT pDriverObj
	)
{	
	int n = 0 ;
	UNICODE_STRING strLink;

	RtlInitUnicodeString(&strLink, LINK_NAME);
	
	//
	// ����ж�ش���
	//

//	CreateTmpThread( TRUE ); // ����ϵͳ�߳�
	for ( ; g_partitionA_sector_pos[n] && n < g_nNumber; n++ )
	{
		Kfree( (PVOID)g_partitionA_sector_pos[n] );
	}

	g_nNumber = 0 ;

	IoDeleteSymbolicLink(&strLink);
	IoDeleteDevice(pDriverObj->DeviceObject);
	dprintf("[sudami] Unloaded\n");
}





NTSTATUS 
DispatchCreate(
	PDEVICE_OBJECT pDevObj, 
	PIRP pIrp
	)
{
	pIrp->IoStatus.Status = STATUS_SUCCESS;
	pIrp->IoStatus.Information = 0;
	IoCompleteRequest(pIrp, IO_NO_INCREMENT);
	return STATUS_SUCCESS;
}



NTSTATUS 
DispatchClose(
	PDEVICE_OBJECT pDevObj, 
	PIRP pIrp
	)
{
	pIrp->IoStatus.Status = STATUS_SUCCESS;
	pIrp->IoStatus.Information = 0;
	IoCompleteRequest( pIrp, IO_NO_INCREMENT );

	return STATUS_SUCCESS;
}



/////////////////////////////////////////////////////////////////         --          --     
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//     --     -      -     -- 
//+                                                           +//     --      -   -       -- 
//+                  DriverInit  -  ��ʼ������                +//      --       -        --  
//+                                                           +//       -     sudami     -   
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//        --            --    
/////////////////////////////////////////////////////////////////          --        --  
//                                                                           --    --
//		    																	--


VOID DriverInit() 
{
	dprintf( "Initialize Driver... \n" );
	
	Get_all_partition_sector();

	if ( NULL == g_atapi_dev ) { // ȡ�� atapi.sys ��DeviceObject
		g_atapi_dev = GetAtaDr0DevObject() ;
	}

//	g_system_ethread = PsGetCurrentThread() ;

//	CreateTmpThread( FALSE ); // ����ϵͳ�߳�

	return ;
}


/////////////////////////////////////////////////////////////////         --          --     
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//     --     -      -     -- 
//+                                                           +//     --      -   -       -- 
//+               �ص��ע - DispatchIoctl                    +//      --       -        --  
//+                                                           +//       -     sudami     -   
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//        --            --    
/////////////////////////////////////////////////////////////////          --        --  
//                                                                           --    --
//		    																	--



typedef struct _Read_Sectors_Context_ {
//	ULONG64 lcn ; 
	ULONG64 fileOffset ;
	int uSectorCounts ;
	int driveId ;
} Read_Sectors_Context, *PRead_Sectors_Context ;


NTSTATUS 
DispatchIoctl(
	PDEVICE_OBJECT pDevObj, 
	PIRP pIrp
	)
{
	NTSTATUS status = STATUS_INVALID_DEVICE_REQUEST;
	PIO_STACK_LOCATION pIrpStack;
	ULONG uIoControlCode;
	PVOID pIoBuffer;
	ULONG uInSize;
	ULONG uOutSize;
	char* target;
	char* source;


	pIrpStack = IoGetCurrentIrpStackLocation(pIrp);
	uIoControlCode = pIrpStack->Parameters.DeviceIoControl.IoControlCode;
	pIoBuffer = pIrp->AssociatedIrp.SystemBuffer;
	uInSize = pIrpStack->Parameters.DeviceIoControl.InputBufferLength;
	uOutSize = pIrpStack->Parameters.DeviceIoControl.OutputBufferLength;

	switch(uIoControlCode) 
	{

	//
	// ��ʼ��������Ϣ
	//
		
	case IOCTL_INIT_SECTORS : 
		{
			__try
			{
				status = STATUS_SUCCESS;
				
				ProbeForRead( pIoBuffer, sizeof( ULONG ), sizeof( ULONG ) );
				
				if( !MmIsAddressValid( (PVOID)pIoBuffer ) )
				{
					DbgPrint("!MmIsAddressValid\n");
					break;
				}
			
				if ( 0 == g_sectors_per_cluster ) 
				{
					g_sectors_per_cluster = *(PULONG) pIoBuffer ; 
					dprintf( "g_sectors_per_cluster : %d", g_sectors_per_cluster );
				}
			}
			__except(1)
			{
				dprintf( "error! IOCTL_INIT_SECTORS | try, __except \n" );
				status = STATUS_UNSUCCESSFUL;
			}
			
			break;
		}

	//
	// ��ȡָ�����������ݵ��û�������
	//

	case IOCTL_READ_SECTORS : 
		{
			//
			//  ��������Buffer��ʽ:
			//    +0x000 u64 fileOffset
			//    +0x008 int uSectorCounts
			//    +0x00C int driveId
			//

			__try
			{
				int driveId = 0 ;
				int nSectorsTotoalSize = 0 ; // Ҫ��ȡ�����ݴ�С
				PRead_Sectors_Context pread_sectors_context = NULL ;
				LARGE_INTEGER realdiskpos = { 0 } ;
				status = STATUS_SUCCESS;
				
			//	ProbeForWrite( pIoBuffer, uOutSize, sizeof( ULONG ) );
				
				pread_sectors_context = (PRead_Sectors_Context) pIoBuffer ;
				driveId = pread_sectors_context->driveId ;

				if ( NULL == pread_sectors_context || pread_sectors_context->uSectorCounts > 500 || NULL == g_partitionA_sector_pos[driveId] ) 
				{
					dprintf( "error! IOCTL_READ_SECTORS | Invalid Buffer \n" );
					break;
				}

				// ���������Ǹ��ļ�����ڸ÷�����offset,����㴦�ڴ����ϵ�������
				realdiskpos.QuadPart = g_partitionA_sector_pos[driveId]->QuadPart + pread_sectors_context->fileOffset ;

				nSectorsTotoalSize = 0x200 * pread_sectors_context->uSectorCounts ;

				// ����2����Ҫ��ȡ�����ݴ�С���ڴ�,���ú������и��Ӳ���. ��Ҫֱ�Ӱ��û�����������,����BSOD
				g_pTmppool = (PVOID) Kmalloc( 2 * nSectorsTotoalSize );
				RtlZeroMemory( g_pTmppool, 2 * nSectorsTotoalSize );

				// ������ʱ�ڴ����
				Scsi_read_file_by_sector( (PVOID)g_pTmppool, (ULONG)realdiskpos.LowPart, pread_sectors_context->uSectorCounts );

 /*++
				//
				// ���ϵͳ�߳̽ṹ����Ϣ
				//

				g_tmpThread_info.ptmpBuffer = g_pTmppool ;
				g_tmpThread_info.sectorPos = (ULONG) realdiskpos.LowPart ;
				g_tmpThread_info.sectorSize = (int) pread_sectors_context->uSectorCounts ;

				KeSetEvent( g_tmpThread_info.Event_SCSI_ReadWrite, 0, FALSE );  // ����Ϊ"����"״̬,���ѵȴ����߳�
				
				// �ȴ��߳����SCSI��д
				KeWaitForSingleObject( g_tmpThread_info.Event_SCSI_ReadWrite_completed, Executive,  KernelMode, FALSE, NULL );
 --*/

				// �� ���������� �� ��ʱ�ڴ���� ������ �û������� ��
				memcpy( pIoBuffer, g_pTmppool, nSectorsTotoalSize );

				// �ͷŵ��ڴ�
				Kfree( g_pTmppool ) ;

				dprintf( "IOCTL_READ_SECTORS | OK! \n" );
			}
			__except(1)
			{
				dprintf("error! IOCTL_READ_SECTORS | try, __except \n");
				status = STATUS_UNSUCCESSFUL;
			}
			
			break;
		}


	}

	if( status == STATUS_SUCCESS )
		pIrp->IoStatus.Information = uOutSize ;
	else
		pIrp->IoStatus.Information = 0 ;
	
	/////////////////////////////////////
	pIrp->IoStatus.Status = status;
	IoCompleteRequest( pIrp, IO_NO_INCREMENT );

	return status;
}



/////////////////////////////////////////////////////////////////         --          --     
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//     --     -      -     -- 
//+                                                           +//     --      -   -       -- 
//+                     SCSI �����д����                     +//      --       -        --  
//+                                                           +//       -     sudami     -   
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//        --            --    
/////////////////////////////////////////////////////////////////          --        --  
//                                                                           --    --
//		    																	--


ULONG  
AtapiReadWriteDisk (
	IN PDEVICE_OBJECT dev_object,
	IN ULONG MajorFunction,
	IN OUT PVOID buffer,
	IN ULONG DiskPos,
	IN int BlockCount
	)
/*++

Author: sudami [sudami@163.com]
Time  : 2009/03/16 [16:3:2009 - 17:29]

Routine Description:
  ����SRB���Atapi.sys�豸, ��/дָ���Ĵ�������  
    
Arguments:
  dev_object - IRP�������豸
  MajorFunction - �����. eg. IRP_MJ_READ 
  buffer - ��/д ������
  DiskPos - Ҫ��ȡ��������ʼ��.  DiskPos = "���ļ���LCN * 8 + ��������������"
  BlockCount - Ҫ��ȡ����������

Return Value:

    
--*/
{
	NTSTATUS status;
	PSCSI_REQUEST_BLOCK srb;
    PSENSE_DATA sense;
	KEVENT Event;
	PIRP irp;
	PMDL mdl;
	IO_STATUS_BLOCK isb;
	PIO_STACK_LOCATION isl;
	PVOID psense;
	int count=8;

	while( 1 )
	{
        srb = Kmalloc( sizeof(SCSI_REQUEST_BLOCK) );
        if( !srb ) break ;

        sense = Kmalloc( sizeof(SENSE_DATA) );
        psense = sense ;
        if( !sense ) break;

        memset( srb, 0, sizeof(SCSI_REQUEST_BLOCK) );
        memset( sense, 0, sizeof(SENSE_DATA) );

        srb->Length					= sizeof(SCSI_REQUEST_BLOCK)	;
		srb->Function				= 0 ;
        srb->DataBuffer				= buffer						;
        srb->DataTransferLength		= BlockCount << 9				; // sector size*number of sector
        srb->QueueAction			= SRB_FLAGS_DISABLE_AUTOSENSE	;
        srb->SrbStatus				= 0								;
        srb->ScsiStatus				= 0								;
        srb->NextSrb				= 0								;
        srb->SenseInfoBuffer		= sense							;
        srb->SenseInfoBufferLength	= sizeof(SENSE_DATA)			;

        if( MajorFunction == IRP_MJ_READ ) {
			srb->SrbFlags = SRB_FLAGS_DATA_IN ;
        } else {
			srb->SrbFlags = SRB_FLAGS_DATA_OUT ;
		}
		
        if( MajorFunction == IRP_MJ_READ ) {
			srb->SrbFlags |= SRB_FLAGS_ADAPTER_CACHE_ENABLE ;
		}
		
		srb->SrbFlags				|= SRB_FLAGS_DISABLE_AUTOSENSE			;
		srb->TimeOutValue			= (srb->DataTransferLength >> 10) + 1	;
		srb->QueueSortKey			= DiskPos								;
		srb->CdbLength				= 10									;
		srb->Cdb[0]					= 2 * ( (UCHAR)MajorFunction + 17 )		;
		srb->Cdb[1]					= srb->Cdb[1] & 0x1F | 0x80				;
		srb->Cdb[2]					= (UCHAR) (DiskPos >> 0x18) & 0xFF		;		
		srb->Cdb[3]					= (UCHAR) (DiskPos >> 0x10) & 0xFF		;		
		srb->Cdb[4]					= (UCHAR) (DiskPos >> 0x08) & 0xFF		;		
		srb->Cdb[5]					= (UCHAR) DiskPos						; // ��дsectorλ��
		srb->Cdb[7]					= (UCHAR) BlockCount >> 0x08			;
		srb->Cdb[8]					= (UCHAR) BlockCount					;
		
		KeInitializeEvent( &Event, 0, 0 );
		irp = IoAllocateIrp( dev_object->StackSize, FALSE );
		mdl = IoAllocateMdl( buffer, BlockCount<<9, 0, 0, irp );
		if( !mdl )
		{
			Kfree( srb );
			Kfree( psense );
			IoFreeIrp( irp );

			return STATUS_INSUFFICIENT_RESOURCES;
		}

	//	MmBuildMdlForNonPagedPool( mdl );
		MmProbeAndLockPages( mdl, 0, (MajorFunction == IRP_MJ_READ ? 0:1) );
		srb->OriginalRequest		=	irp								;
		irp->MdlAddress				=	mdl								;
		irp->UserIosb				=	&isb							;
		irp->UserEvent				=	&Event							;
		irp->IoStatus.Status		=	0								;
		irp->IoStatus.Information	=	0								;
		irp->Flags					=	IRP_SYNCHRONOUS_API|IRP_NOCACHE ;
		irp->AssociatedIrp.SystemBuffer = 0								;
		irp->Cancel					=   0								;
		irp->RequestorMode			=	0								;
		irp->CancelRoutine			=	0								;
		irp->Tail.Overlay.Thread	=	PsGetCurrentThread()			;

		isl							= IoGetNextIrpStackLocation( irp )	;
		isl->DeviceObject			=	dev_object						;
		isl->MajorFunction			=	IRP_MJ_SCSI						;
		isl->Parameters.Scsi.Srb	=	srb								;
		isl->CompletionRoutine		=	IrpCompletionRoutine_0			;
        isl->Context				=	srb								;
        isl->Control				=	SL_INVOKE_ON_CANCEL | SL_INVOKE_ON_SUCCESS | SL_INVOKE_ON_ERROR ;

		status = IoCallDriver( dev_object, irp );
		KeWaitForSingleObject( &Event, 0, 0, 0, 0 );
		
// 		if( srb->SenseInfoBuffer != psense && srb->SenseInfoBuffer ) {
// 			ExFreePool( srb->SenseInfoBuffer );
// 		}

		Kfree( srb );
		Kfree( psense );
		
        if ( status >= 0 || !count )
			return status;
		
		DbgPrint("error! AtapiReadWriteDisk() | Send SRB Failed: %08x\r\n", status);
		KeStallExecutionProcessor( 1u );
		--count ;
	}

	return STATUS_INSUFFICIENT_RESOURCES;
}



VOID 
Scsi_read_file_by_name ( 
	IN WCHAR* wszFilePath 
	)
/*++

Author: sudami [sudami@163.com]
Time  : 2009/03/16 [16:3:2009 - 17:30]

Routine Description:
  ����SCSI�����ָ��·�����ļ�
    
Arguments:
  wszFilePath - Ҫ�����ļ�ȫ·��
    
--*/
{
	LARGE_INTEGER realdiskpos ;
	PLARGE_INTEGER filesize;
	PVOID buf = NULL ;
	ULONG psector, TmpSize = 0 ;

	if ( NULL == wszFilePath ){ 
		return ;
	}

	realdiskpos = Get_file_SectorPoint( wszFilePath );
	filesize = Get_file_size( wszFilePath );

	TmpSize = ( (filesize->LowPart / 512) + 1 ) * 512 + 100 ;
	buf = Kmalloc ( TmpSize );
	if ( NULL == buf )
	{
		dprintf( "error! Scsi_read_file_by_name() | �����ڴ�ʧ�� \n" );
		return ;
	}

	memset( buf, 0x00, TmpSize );
	
	if ( NULL == g_atapi_dev ) {
		g_atapi_dev = GetAtaDr0DevObject() ;
	}
	
	psector = realdiskpos.LowPart;

	if( g_atapi_dev && psector && buf )
	{
		AtapiReadWriteDisk( g_atapi_dev, IRP_MJ_READ, buf, psector, (filesize->LowPart / 512) + 1 );
		dprintf( "���ļ�������:\n %s \n\n", (char*)buf );
	}

	Kfree( buf );

	return ;
}



VOID
Scsi_read_file_by_sector ( 
	OUT PVOID buffer,
	IN ULONG DiskPos,
	IN int BlockCount
	) 
/*++

Author: sudami [sudami@163.com]
Time  : 2009/03/16 [16:3:2009 - 17:24]

Routine Description:
  ����SCSIָ���ȡָ��������  
    
Arguments:
  buffer - �����ȡ������ 
  DiskPos - Ҫ��ȡ��������ʼ��.  DiskPos = "���ļ���LCN * 8 + ��������������"
  BlockCount - Ҫ��ȡ����������

--*/
{
	if ( 0 == BlockCount ) // �����Ϸ��Լ��
	{
		dprintf( "error! Scsi_read_file_by_sector() | Invalid Parameters \n" );
		return;
	}

	if ( NULL == g_atapi_dev ) // ȡ�� atapi.sys ��DeviceObject
	{
		g_atapi_dev = GetAtaDr0DevObject() ;
		if ( NULL == g_atapi_dev ) 
		{ 
			dprintf( "error! Scsi_read_file_by_sector() | can't get atapi's deviceObject \n" );
			return; 
		}
	}

	// ��ȡ ָ�������� �� �û�������
	dprintf( "\n IOCTL | ReadSectors | ���ļ��ڴ�����Ҫ��������ʼ������: 0x%08lx \n", DiskPos );
	AtapiReadWriteDisk( g_atapi_dev, IRP_MJ_READ, buffer, DiskPos, BlockCount );

	dprintf( "���ļ�������:\n %s \n\n", (char*)buffer );

	return ;
}



VOID 
Scsi_write_file_by_sector ( 
	IN PVOID buffer,
	IN ULONG DiskPos,
	IN int BlockCount
	) 
/*++

Author: sudami [sudami@163.com]
Time  : 2009/03/16 [16:3:2009 - 17:24]

Routine Description:
  ����SCSIָ��дָ��������  
    
Arguments:
  buffer - Ҫд������� 
  DiskPos - Ҫд���������ʼ��.  DiskPos = "���ļ���LCN * 8 + ��������������"
  BlockCount - Ҫд�����������

--*/
{
	if ( 0 == BlockCount ) // �����Ϸ��Լ��
	{
		dprintf( "error! Scsi_write_file_by_sector() | Invalid Parameters \n" );
		return;
	}

	if ( NULL == g_atapi_dev )  // ȡ�� atapi.sys ��DeviceObject
	{
		g_atapi_dev = GetAtaDr0DevObject() ;
		if ( NULL == g_atapi_dev ) 
		{ 
			dprintf( "error! Scsi_write_file_by_sector() can't get atapi's deviceObject \n" );
			return; 
		}
	}
	
	// �� �û��������е����� д�� ָ��������
	AtapiReadWriteDisk( g_atapi_dev, IRP_MJ_WRITE, buffer, DiskPos, BlockCount );
	
	return ;
}


///////////////////////////////   END OF FILE   ///////////////////////////////