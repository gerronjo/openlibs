/***************************************************************************************
* AUTHOR : sudami [sudami@163.com]
* TIME   : 2008/08/13 
* MODULE : mpDn.H
* 
* Command: 
*   
*   
*
* Description:
*   
*                        
*
***
* Copyright (c) 2008 - 2010 sudami.
* Freely distributable in source or binary for noncommercial purposes.
* TAKE IT EASY,JUST FOR FUN.
*
****************************************************************************************/

#include <devioctl.h>
#include <ntddk.h>

#ifndef _MPDN_H
#define _MPDN_H 1


/////////////////////////////////////////////////////////////////////

#define dprintf if (DBG) DbgPrint
#define nprintf DbgPrint

#define DEVICE_NAME L"\\Device\\SRB"	
#define LINK_NAME L"\\DosDevices\\SRB"	


/////////////////////////////////////////////////////////////////////

NTSTATUS DriverEntry(PDRIVER_OBJECT pDriverObj, PUNICODE_STRING pRegistryString);
NTSTATUS DispatchCreate(PDEVICE_OBJECT pDevObj, PIRP pIrp);
NTSTATUS DispatchClose(PDEVICE_OBJECT pDevObj, PIRP pIrp);
VOID DriverUnload(PDRIVER_OBJECT pDriverObj);
NTSTATUS DispatchIoctl(PDEVICE_OBJECT pDevObj, PIRP pIrp);

VOID DriverInit() ;
VOID Scsi_read_file_by_name ( WCHAR* wszFilePath ) ;

VOID 
Scsi_read_file_by_sector ( 
	OUT PVOID buffer,
	IN ULONG DiskPos,
	int BlockCount
	) ;

VOID 
Scsi_write_file_by_sector ( 
	IN PVOID buffer,
	IN ULONG DiskPos,
	int BlockCount
	) ;

ULONG  
AtapiReadWriteDisk (
	IN PDEVICE_OBJECT dev_object,
	IN ULONG MajorFunction,
	IN OUT PVOID buffer,
	IN ULONG DiskPos,
	int BlockCount
	) ;


/////////////////////////////////////////////////////////////////////



#endif

///////////////////////////////   END OF FILE   ///////////////////////////////