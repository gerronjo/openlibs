/***************************************************************************************
* AUTHOR : sudami [sudami@163.com]
* TIME   : 2008/12/21 [21:12:2008 - 18:39]
* MODULE : D:\Company\360\Projects\2008.12\HIPS\Code\VirusAnalyse_All\CreateTmpThread.c
*
* Description:
*   
*   ����һ�������߳�,��������;                       
*
***
* Copyright (c) 2008 - 2010 sudami.
* Freely distributable in source or binary for noncommercial purposes.
* TAKE IT EASY,JUST FOR FUN.
*
****************************************************************************************/

#include "struct.h"
#include "header.h"
#include "ioctl.h"
#include "CreateTmpThread.h"
#include "mpDn.h"

#include <stdio.h>
#include <stdlib.h>

//////////////////////////////////////////////////////////////////////////

THREAD_INFO g_tmpThread_info ;

//////////////////////////////////////////////////////////////////////////


/////////////////////////////////////////////////////////////////         --          --     
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//     --     -      -     -- 
//+                                                           +//     --      -   -       -- 
//+						��ʼϵͳ�߳�                          +//      --       -        --  
//+                                                           +//       -     sudami     -   
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++//        --            --    
/////////////////////////////////////////////////////////////////          --        --  
//                                                                           --    --
//		    																	--

VOID 
CreateTmpThread(
	IN BOOL bTerminate
	) 
{
	HANDLE ThreadHandle;
	
	if ( FALSE == bTerminate ) { // ��������
		
		if (!NT_SUCCESS(PsCreateSystemThread (&ThreadHandle,
			THREAD_ALL_ACCESS,
			NULL,
			0L,
			NULL,
			MyTmpThread,
			NULL))
		   ) 
		{
			dprintf("CreateTmpThread() -->PsCreateSystemThread. Failed\n");
			return;
		}
		
		ObReferenceObjectByHandle (ThreadHandle,
			THREAD_ALL_ACCESS,
			NULL,
			KernelMode,
			(PVOID *)&g_tmpThread_info.pThreadObj,
			NULL);
		
		//
		// ��ʼ���ý��̵Ľṹ��
		//

		g_tmpThread_info.bRepeat_thread			= TRUE ;
		g_tmpThread_info.bIamRunning			= TRUE ;
		g_tmpThread_info.Event_SCSI_ReadWrite	= (PKEVENT) Kmalloc( sizeof(KEVENT) ); 
		g_tmpThread_info.Event_SCSI_ReadWrite_completed	= (PKEVENT) Kmalloc( sizeof(KEVENT) ); 
		g_tmpThread_info.ptmpBuffer				= NULL ;
		g_tmpThread_info.sectorPos				= 0 ;
		g_tmpThread_info.sectorCounts				= 0 ;
		
		if ( !g_tmpThread_info.Event_SCSI_ReadWrite || !g_tmpThread_info.Event_SCSI_ReadWrite_completed ) 
		{
			// �������ڴ�ʧ��,���˳�ϵͳ����
			CreateTmpThread( TRUE );
		}

		KeInitializeEvent( g_tmpThread_info.Event_SCSI_ReadWrite, NotificationEvent, FALSE );
		KeInitializeEvent( g_tmpThread_info.Event_SCSI_ReadWrite_completed, NotificationEvent, FALSE );
		
		ZwClose (ThreadHandle);
		
	} 
	else // ���ٽ���
	{  	
		if ( FALSE == g_tmpThread_info.bIamRunning )
		{
			// ���߳��Ѿ�����,���ͷ��ڴ����
			Kfree( g_tmpThread_info.Event_SCSI_ReadWrite );
			Kfree( g_tmpThread_info.Event_SCSI_ReadWrite_completed );
			return ;
		} 

		// ���߳�û�н���,��ȴ������,����ͷ��ڴ�
		g_tmpThread_info.bRepeat_thread = FALSE ; // ֹͣ�߳�
		g_tmpThread_info.bIamRunning	= FALSE ;

		KeSetEvent( g_tmpThread_info.Event_SCSI_ReadWrite, 0, FALSE );  // ����Ϊ"����"״̬,���ѵȴ����߳�
		
		if ( g_tmpThread_info.pThreadObj != NULL ) { // �ȴ��̵߳Ľ���
			KeWaitForSingleObject( g_tmpThread_info.pThreadObj, Executive, KernelMode, FALSE, NULL );	
		}
		
		if ( g_tmpThread_info.pThreadObj != NULL ) { // �� thread object����,�ͷŵ�,Ҫ����BSOD
			ObDereferenceObject( g_tmpThread_info.pThreadObj );
			g_tmpThread_info.pThreadObj = NULL;
		}

		Kfree( g_tmpThread_info.Event_SCSI_ReadWrite );
		Kfree( g_tmpThread_info.Event_SCSI_ReadWrite_completed );
	}
	
	return ;
}



VOID
MyTmpThread (
	IN PVOID StartContext
	)
{
	ULONG i;
	LARGE_INTEGER interval;
	interval.QuadPart = -1 * 1000 * 100 * 100;     // 2000ms, relative
	
	while (TRUE) 
	{ 
		// ϵͳ�߳̽���ʱҪ����������ڴ�
		if ( FALSE == g_tmpThread_info.bRepeat_thread )
		{
			dprintf("SCSI - Terminate Our Thread \n");
			
			g_tmpThread_info.bIamRunning = FALSE ;
			PsTerminateSystemThread( STATUS_SUCCESS );
		}

		// ÿ��ѭ����,����������Ϊ��
		g_tmpThread_info.ptmpBuffer				= NULL ;
		g_tmpThread_info.sectorPos				= 0 ;
		g_tmpThread_info.sectorCounts				= 0 ;
		
		// ѭ��һ��,����������EVENTΪ"δ����"״̬.���̵߳ȴ�����
		KeClearEvent( g_tmpThread_info.Event_SCSI_ReadWrite );
		KeClearEvent( g_tmpThread_info.Event_SCSI_ReadWrite_completed );
		
		// �ȴ��¼���һֱ��"����"״̬
		dprintf( "I'm Waiting... \n" );
		KeWaitForSingleObject( g_tmpThread_info.Event_SCSI_ReadWrite, Executive, KernelMode, FALSE, NULL );
		//	KeDelayExecutionThread( KernelMode, FALSE, &interval ); // �ӳ�2����
		
		//
		// ������
		//
	
		Scsi_read_file_by_sector( g_tmpThread_info.ptmpBuffer, g_tmpThread_info.sectorPos, g_tmpThread_info.sectorCounts );
			
		//	Already done!
		KeSetEvent( g_tmpThread_info.Event_SCSI_ReadWrite_completed, 0, FALSE );  // ����Ϊ"����"״̬�����ѵȴ���
	}

	return ;
}


/////////////////////////////////////// END OF FILE ///////////////////////////////////////////