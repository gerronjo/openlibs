#ifndef _HEADER_H
#define _HEADER_H 1

#include <ntddk.h>

//////////////////////////////////////////////////////////////////////////

#define dprintf if (DBG) DbgPrint
#define nprintf DbgPrint

#define Kmalloc(_s)	ExAllocatePool(NonPagedPool, _s)
#define Kfree(_p)	if( _p ) { ExFreePool(_p); }

#define KmallocClear(_s)				\
{										\
	PVOID pBuffer = Kmalloc(_s);		\
	memset( pBuffer, 0, _s );			\
	pBuffer ;							\
}

#define FSCTL_GET_RETRIEVAL_POINTERS 0x90073
#define PARTITION_TYPE_NTFS         0x07
#define PARTITION_TYPE_FAT32         0x0B
#define PARTITION_TYPE_FAT32_LBA     0x0C


typedef struct RETRIEVAL_POINTERS_BUFFER {
	ULONG ExtentCount;
	LARGE_INTEGER StartingVcn;
	struct {
		LARGE_INTEGER NextVcn;
		LARGE_INTEGER Lcn;
	} Extents[1]; 
} RETRIEVAL_POINTERS_BUFFER, *PRETRIEVAL_POINTERS_BUFFER;

typedef struct {  
	LARGE_INTEGER StartingVcn;
} STARTING_VCN_INPUT_BUFFER,  *PSTARTING_VCN_INPUT_BUFFER;


// typedef struct _SENSE_DATA {
// 	unsigned char Valid;
// 	unsigned char SegmentNumber;
// 	unsigned char FileMark;
// 	unsigned char Information[4];
// 	unsigned char AdditionalSenseLength;
// 	unsigned char CommandSpecificInformation[4];
// 	unsigned char AdditionalSenseCode;
// 	unsigned char AdditionalSenseCodeQualifier;
// 	unsigned char FieldReplaceableUnitCode;
// 	unsigned char SenseKeySpecific[3];
// } SENSE_DATA, *PSENSE_DATA; 


#pragma pack(1)
typedef struct _PARTITION_ENTRY
{
	UCHAR active;                
	UCHAR StartHead;              
	UCHAR StartSector;             
	UCHAR StartCylinder;          
	UCHAR PartitionType;          
	UCHAR EndHead;                
	UCHAR EndSector;              
	UCHAR EndCylinder;           
	ULONG StartLBA;              
	ULONG TotalSector;            
} PARTITION_ENTRY, *PPARTITION_ENTRY;


typedef struct _MBR_SECTOR
{
	UCHAR             BootCode[446];
	PARTITION_ENTRY   Partition[4];
	USHORT           Signature;
} MBR_SECTOR, *PMBR_SECTOR;


typedef struct _BBR_SECTOR
{
	USHORT JmpCode;				// 0x000     
	UCHAR   NopCode;			// 0x002     
	UCHAR   OEMName[8];			// 0x003    
	USHORT BytesPerSector;		// 0x00B    
	UCHAR   SectorsPerCluster;  // 0x00D 
	USHORT ReservedSectors;		// 0x00E	
	UCHAR   NumberOfFATs;       // 0x010
	USHORT RootEntries;       
	USHORT NumberOfSectors16;    
	UCHAR   MediaDescriptor;     
	USHORT SectorsPerFAT16;     
	USHORT SectorsPerTrack;     
	USHORT HeadsPerCylinder;     
	ULONG   HiddenSectors;      
	ULONG   NumberOfSectors32;    
	ULONG   SectorsPerFAT32;      
} BBR_SECTOR, *PBBR_SECTOR;
#pragma pack()


typedef struct _SYSTEM_MODULE_INFORMATION {
	ULONG Reserved[2];
	PVOID Base;
	ULONG Size;
	ULONG Flags;
	USHORT Index;
	USHORT Unknown;
	USHORT LoadCount;
	USHORT ModuleNameOffset;              
	CHAR ImageName[255];  
} SYSTEM_MODULE_INFORMATION, *PSYSTEM_MODULE_INFORMATION;


//////////////////////////////////////////////////////////////////////////

NTSYSAPI
NTSTATUS
NTAPI
ObReferenceObjectByName(
						IN PUNICODE_STRING ObjectName,
						IN ULONG Attributes,
						IN PACCESS_STATE AccessState OPTIONAL,
						IN ACCESS_MASK DesiredAccess OPTIONAL,
						IN POBJECT_TYPE ObjectType,
						IN KPROCESSOR_MODE AccessMode,
						IN OUT PVOID ParseContext OPTIONAL,
						OUT PVOID* Object );

NTSYSAPI
NTSTATUS
NTAPI
ZwQuerySystemInformation(
						 IN ULONG SystemInformationClass,
						 IN OUT PVOID SystemInformation,
						 IN ULONG SystemInformationLength,
						 OUT PULONG ReturnLength);


//////////////////////////////////////////////////////////////////////////

#endif